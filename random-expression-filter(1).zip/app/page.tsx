"use client"

import { useState, useRef, useEffect, useCallback } from 'react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Camera, CameraOff, Download, RotateCcw, Sparkles, Zap, Brain, Heart, Star, Volume2, VolumeX, Gamepad2, Music, Palette, Wand2, Rocket, Disc, Radio, Headphones, Car, Trophy, Flag, Timer, Users } from 'lucide-react'

// Expression to emoji mappings
const EXPRESSION_EMOJIS = {
  happy: ['😄', '😊', '😁', '🙂', '😃'],
  sad: ['😢', '😭', '😞', '☹️', '😔'],
  angry: ['😠', '😡', '🤬', '😤', '👿'],
  surprised: ['😲', '😯', '😮', '🤯', '😱'],
  neutral: ['😐', '😑', '🙄', '😶', '😒'],
  disgusted: ['🤢', '🤮', '😷', '🤧', '😖'],
  fearful: ['😨', '😰', '😱', '🫣', '😧']
}

const ALL_EMOJIS = [
  '🤡', '🤖', '👽', '👻', '💀', '🎭', '🦄', '🐸', '🐵', '🐶',
  '🐱', '🦊', '🐼', '🐨', '🐯', '🦁', '🐷', '🐮', '🐙', '🦋',
  '🍕', '🍔', '🍟', '🌮', '🍩', '🎂', '🍎', '🍌', '🥑', '🥕',
  '⚽', '🏀', '🎾', '🏈', '🎱', '🎯', '🎪', '🎨', '🎭', '🎪',
  '🚀', '✈️', '🚁', '🚂', '🚗', '🏠', '🏰', '🗽', '🎡', '🎢',
  '⭐', '🌟', '✨', '💫', '🌈', '🔥', '💎', '👑', '🎊', '🎉'
]

const FLOATING_EMOJIS = [
  '😵‍💫', '🤪', '🥴', '😜', '🤨', '🧐', '🤓', '😎', '🥸', '🤠',
  '👾', '🎲', '🎯', '🎪', '🎨', '🎭', '🎪', '🎊', '🎉', '✨',
  '💫', '⭐', '🌟', '🔮', '🎱', '🎰', '🎲', '🃏', '🎴', '🀄',
  '🌙', '☄️', '🪐', '🌌', '🌠', '💥', '⚡', '🔥', '❄️', '🌊',
  '🎵', '🎶', '🎼', '🎤', '🎧', '📻', '🔊', '📢', '📯', '🎺'
]

const SIDE_EMOJIS = [
  '🎭', '🎪', '🎨', '🎯', '🎲', '🎰', '🃏', '🎴', '🀄', '🎵',
  '🎶', '🎼', '🎤', '🎧', '📻', '🔊', '📢', '📯', '🎺', '🎸',
  '🥁', '🎹', '🎻', '🪕', '🎷', '🪗', '🪘', '🔔', '🔕', '📯'
]

const CREATIVE_FRAMES = [
  { name: 'None', style: '', glow: '' },
  { name: 'Neon Pink', style: 'border-4 border-pink-500', glow: 'shadow-[0_0_30px_#ec4899,0_0_60px_#ec4899,0_0_90px_#ec4899]' },
  { name: 'Cyber Blue', style: 'border-4 border-cyan-400', glow: 'shadow-[0_0_30px_#22d3ee,0_0_60px_#22d3ee,0_0_90px_#22d3ee]' },
  { name: 'Electric Purple', style: 'border-4 border-purple-500', glow: 'shadow-[0_0_30px_#a855f7,0_0_60px_#a855f7,0_0_90px_#a855f7]' },
  { name: 'Toxic Green', style: 'border-4 border-green-400', glow: 'shadow-[0_0_30px_#4ade80,0_0_60px_#4ade80,0_0_90px_#4ade80]' },
  { name: 'Fire Orange', style: 'border-4 border-orange-500', glow: 'shadow-[0_0_30px_#f97316,0_0_60px_#f97316,0_0_90px_#f97316]' },
  { name: 'Galaxy', style: 'border-4 border-indigo-500', glow: 'shadow-[0_0_40px_#6366f1,0_0_80px_#8b5cf6,0_0_120px_#ec4899]' },
  { name: 'Holographic', style: 'border-4 border-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500', glow: 'shadow-[0_0_50px_#ec4899,0_0_100px_#a855f7,0_0_150px_#22d3ee]' },
  { name: 'Sound Wave', style: 'border-4 border-transparent', glow: 'shadow-[0_0_30px_#22d3ee,0_0_60px_#a855f7,0_0_90px_#ec4899]' }
]

const COLOR_THEMES = [
  { name: 'Cyberpunk', bg: 'from-gray-900 via-purple-900 to-black', accent: 'cyan' },
  { name: 'Sunset', bg: 'from-orange-900 via-red-900 to-pink-900', accent: 'orange' },
  { name: 'Ocean', bg: 'from-blue-900 via-teal-900 to-cyan-900', accent: 'blue' },
  { name: 'Forest', bg: 'from-green-900 via-emerald-900 to-teal-900', accent: 'green' },
  { name: 'Galaxy', bg: 'from-indigo-900 via-purple-900 to-pink-900', accent: 'purple' },
  { name: 'Neon', bg: 'from-black via-gray-900 to-black', accent: 'pink' },
  { name: 'Synthwave', bg: 'from-purple-900 via-pink-800 to-indigo-900', accent: 'pink' },
  { name: 'Disco', bg: 'from-black via-purple-900 to-black', accent: 'gold' }
]

const SPECIAL_MODES = [
  'Normal', 'Disco', 'Constellation', 'Portal', 'Fireworks', 'DNA Spiral', 'Weather Storm', 'Audio Reactive', 'Racing Mode'
]

const MUSIC_STYLES = [
  'Ambient', 'Synthwave', 'Chiptune', 'Lo-Fi', 'Techno', 'Cosmic', 'Racing'
]

// Racing Game Data
const RACING_VEHICLES = [
  { 
    id: 'sports', 
    name: '🏎️ Sports Car', 
    emoji: '🏎️', 
    speed: 8, 
    acceleration: 7, 
    handling: 6,
    color: '#ff4444'
  },
  { 
    id: 'formula', 
    name: '🏁 Formula Car', 
    emoji: '🏁', 
    speed: 10, 
    acceleration: 6, 
    handling: 8,
    color: '#44ff44'
  },
  { 
    id: 'truck', 
    name: '🚛 Racing Truck', 
    emoji: '🚛', 
    speed: 5, 
    acceleration: 9, 
    handling: 4,
    color: '#4444ff'
  },
  { 
    id: 'motorcycle', 
    name: '🏍️ Motorcycle', 
    emoji: '🏍️', 
    speed: 9, 
    acceleration: 10, 
    handling: 7,
    color: '#ff44ff'
  },
  { 
    id: 'taxi', 
    name: '🚕 Taxi Racer', 
    emoji: '🚕', 
    speed: 6, 
    acceleration: 5, 
    handling: 9,
    color: '#ffff44'
  },
  { 
    id: 'police', 
    name: '🚓 Police Car', 
    emoji: '🚓', 
    speed: 7, 
    acceleration: 8, 
    handling: 7,
    color: '#44ffff'
  }
]

const RACING_TRACKS = [
  {
    id: 'city',
    name: '🏙️ Neon City Circuit',
    emoji: '🏙️',
    difficulty: 'Medium',
    laps: 3,
    obstacles: ['🏢', '🚧', '🚦'],
    theme: 'cyberpunk'
  },
  {
    id: 'desert',
    name: '🏜️ Desert Storm Track',
    emoji: '🏜️',
    difficulty: 'Hard',
    laps: 4,
    obstacles: ['🌵', '🪨', '💨'],
    theme: 'desert'
  },
  {
    id: 'forest',
    name: '🌲 Forest Rally',
    emoji: '🌲',
    difficulty: 'Easy',
    laps: 2,
    obstacles: ['🌳', '🦌', '🍄'],
    theme: 'forest'
  },
  {
    id: 'space',
    name: '🚀 Cosmic Speedway',
    emoji: '🚀',
    difficulty: 'Extreme',
    laps: 5,
    obstacles: ['🛸', '☄️', '🌌'],
    theme: 'space'
  },
  {
    id: 'beach',
    name: '🏖️ Sunset Beach',
    emoji: '🏖️',
    difficulty: 'Easy',
    laps: 3,
    obstacles: ['🌴', '🦀', '🏄'],
    theme: 'beach'
  },
  {
    id: 'volcano',
    name: '🌋 Volcano Circuit',
    emoji: '🌋',
    difficulty: 'Extreme',
    laps: 4,
    obstacles: ['🔥', '💎', '🌋'],
    theme: 'volcano'
  }
]

const SOUND_EFFECTS = [
  "🔊 *BEEP BOOP* Camera activated!",
  "🎵 *WHOOSH* Emoji locked and loaded!",
  "📸 *SNAP* Photo captured with maximum chaos!",
  "🎪 *DING DING* New mismatch detected!",
  "🚀 *ZOOM* Frame effect applied!",
  "🎭 *TADA* Perfect imperfection achieved!",
  "⚡ *ZAP* Cosmic energy recharged!",
  "🎲 *ROLL* Random chaos initiated!",
  "🎧 *WUBWUB* Bass drop activated!",
  "🎹 *PLINK PLONK* Musical mayhem engaged!",
  "🎺 *TOOT* Sonic disruption complete!",
  "🥁 *BOOM* Beat dropped successfully!",
  "🏎️ *VROOM* Engine revving!",
  "🏁 *SCREECH* Tires burning rubber!",
  "💥 *CRASH* Epic collision detected!",
  "🎯 *DING* Checkpoint reached!"
]

const USELESS_FACTS = [
  "🧠 Did you know? Your emoji mismatch rate is scientifically proven to be exactly 100%!",
  "🔬 Fun fact: This algorithm has never been right, not even once in 47,392 attempts!",
  "📰 Breaking: Local person discovers their face doesn't match any emoji ever created!",
  "🤯 Scientists baffled: How can someone look so different from a yellow circle?",
  "🤖 Your face has been analyzed by our advanced AI (Absolutely Inaccurate) system!",
  "🏆 Congratulations! You've achieved peak facial-emoji incompatibility!",
  "⏰ This app has wasted exactly 47.3 seconds of your life so far!",
  "🎯 Your expression confusion level: MAXIMUM ACHIEVED!",
  "🌟 You're now 73% more confused than when you started!",
  "🎪 Warning: Prolonged use may cause uncontrollable laughter!",
  "🎵 The background music is composed by our AI DJ (Absolutely Inaccurate DJ)!",
  "🌈 You've unlocked a new level of digital absurdity!",
  "🚀 Your chaos energy is now powering three small cities!",
  "🎧 This music has been scientifically designed to confuse your brain!",
  "🎹 Our AI composer failed music school 17 times before creating this masterpiece!",
  "🎛️ These beats are made from recycled digital chaos particles!",
  "🏎️ Your racing skills are inversely proportional to your emoji accuracy!",
  "🏁 Scientists confirm: Racing while confused increases lap times by 420%!",
  "🚗 This racing game was coded by caffeinated hamsters on tiny keyboards!",
  "🏆 Your virtual driving is somehow worse than your real-life selfies!"
]

// Racing Game Classes
class RacingGame {
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D
  private gameState: 'menu' | 'racing' | 'paused' | 'finished' = 'menu'
  private selectedVehicle: typeof RACING_VEHICLES[0] | null = null
  private selectedTrack: typeof RACING_TRACKS[0] | null = null
  private playerPosition = { x: 0, y: 0, angle: 0 }
  private velocity = { x: 0, y: 0 }
  private speed = 0
  private maxSpeed = 8
  private acceleration = 0.3
  private friction = 0.95
  private turnSpeed = 0.05
  private currentLap = 1
  private raceTime = 0
  private checkpoints: Array<{x: number, y: number, passed: boolean}> = []
  private obstacles: Array<{x: number, y: number, type: string}> = []
  private particles: Array<{x: number, y: number, vx: number, vy: number, life: number, color: string}> = []
  private keys: {[key: string]: boolean} = {}
  private animationId: number | null = null
  private onRaceComplete: ((time: number, position: number) => void) | null = null
  private audioSystem: AudioSystem | null = null
  private lastTime = 0
  private aiCars: Array<{x: number, y: number, angle: number, speed: number, vehicle: typeof RACING_VEHICLES[0]}> = []
  private raceStartTime = 0
  private isRaceStarted = false
  private countdown = 3

  constructor(canvas: HTMLCanvasElement, audioSystem: AudioSystem | null) {
    this.canvas = canvas
    this.ctx = canvas.getContext('2d')!
    this.audioSystem = audioSystem
    this.setupEventListeners()
    this.initializeTrack()
  }

  private setupEventListeners() {
    const handleKeyDown = (e: KeyboardEvent) => {
      this.keys[e.key.toLowerCase()] = true
      if (e.key === ' ') e.preventDefault()
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      this.keys[e.key.toLowerCase()] = false
    }

    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('keyup', handleKeyUp)
  }

  private initializeTrack() {
    // Initialize checkpoints in a circular pattern
    const centerX = this.canvas.width / 2
    const centerY = this.canvas.height / 2
    const radius = Math.min(this.canvas.width, this.canvas.height) * 0.3

    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2
      this.checkpoints.push({
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        passed: i === 0 // First checkpoint starts as passed
      })
    }

    // Initialize obstacles
    this.obstacles = []
    for (let i = 0; i < 15; i++) {
      this.obstacles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        type: this.selectedTrack?.obstacles[Math.floor(Math.random() * this.selectedTrack.obstacles.length)] || '🚧'
      })
    }

    // Initialize AI cars
    this.aiCars = []
    for (let i = 0; i < 3; i++) {
      const vehicle = RACING_VEHICLES[Math.floor(Math.random() * RACING_VEHICLES.length)]
      this.aiCars.push({
        x: centerX + (i + 1) * 50,
        y: centerY + 100,
        angle: 0,
        speed: 0,
        vehicle
      })
    }

    // Set player starting position
    this.playerPosition = { x: centerX, y: centerY + 100, angle: 0 }
  }

  setVehicle(vehicle: typeof RACING_VEHICLES[0]) {
    this.selectedVehicle = vehicle
    this.maxSpeed = vehicle.speed
    this.acceleration = vehicle.acceleration * 0.05
    this.turnSpeed = vehicle.handling * 0.01
  }

  setTrack(track: typeof RACING_TRACKS[0]) {
    this.selectedTrack = track
    this.initializeTrack()
  }

  startRace() {
    if (!this.selectedVehicle || !this.selectedTrack) return
    
    this.gameState = 'racing'
    this.raceTime = 0
    this.currentLap = 1
    this.isRaceStarted = false
    this.countdown = 3
    this.raceStartTime = Date.now()
    
    // Reset checkpoints
    this.checkpoints.forEach((checkpoint, index) => {
      checkpoint.passed = index === 0
    })

    this.gameLoop()
    
    if (this.audioSystem) {
      this.audioSystem.playSound('race_start')
    }
  }

  private gameLoop = (currentTime: number = 0) => {
    if (this.gameState !== 'racing') return

    const deltaTime = currentTime - this.lastTime
    this.lastTime = currentTime

    // Handle countdown
    if (!this.isRaceStarted) {
      const elapsed = (Date.now() - this.raceStartTime) / 1000
      this.countdown = Math.max(0, 3 - Math.floor(elapsed))
      
      if (this.countdown === 0 && elapsed > 3) {
        this.isRaceStarted = true
        if (this.audioSystem) {
          this.audioSystem.playSound('race_go')
        }
      }
    } else {
      this.raceTime += deltaTime / 1000
      this.updateGame(deltaTime)
    }

    this.render()
    this.animationId = requestAnimationFrame(this.gameLoop)
  }

  private updateGame(deltaTime: number) {
    if (!this.isRaceStarted) return

    // Handle input
    if (this.keys['arrowup'] || this.keys['w']) {
      this.speed = Math.min(this.speed + this.acceleration, this.maxSpeed)
      this.addEngineParticles()
    }
    if (this.keys['arrowdown'] || this.keys['s']) {
      this.speed = Math.max(this.speed - this.acceleration * 1.5, -this.maxSpeed * 0.5)
    }
    if (this.keys['arrowleft'] || this.keys['a']) {
      this.playerPosition.angle -= this.turnSpeed * Math.abs(this.speed)
    }
    if (this.keys['arrowright'] || this.keys['d']) {
      this.playerPosition.angle += this.turnSpeed * Math.abs(this.speed)
    }

    // Apply friction
    this.speed *= this.friction

    // Update position
    this.velocity.x = Math.cos(this.playerPosition.angle) * this.speed
    this.velocity.y = Math.sin(this.playerPosition.angle) * this.speed
    
    this.playerPosition.x += this.velocity.x
    this.playerPosition.y += this.velocity.y

    // Keep player in bounds
    this.playerPosition.x = Math.max(20, Math.min(this.canvas.width - 20, this.playerPosition.x))
    this.playerPosition.y = Math.max(20, Math.min(this.canvas.height - 20, this.playerPosition.y))

    // Update AI cars
    this.updateAICars()

    // Check collisions with obstacles
    this.checkObstacleCollisions()

    // Check checkpoint progression
    this.checkCheckpoints()

    // Update particles
    this.updateParticles()

    // Check race completion
    if (this.currentLap > (this.selectedTrack?.laps || 3)) {
      this.finishRace()
    }
  }

  private updateAICars() {
    this.aiCars.forEach(car => {
      // Simple AI: move towards next checkpoint
      const nextCheckpoint = this.getNextCheckpoint()
      if (nextCheckpoint) {
        const dx = nextCheckpoint.x - car.x
        const dy = nextCheckpoint.y - car.y
        const targetAngle = Math.atan2(dy, dx)
        
        // Smooth angle adjustment
        let angleDiff = targetAngle - car.angle
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2
        
        car.angle += angleDiff * 0.02
        car.speed = Math.min(car.speed + 0.1, car.vehicle.speed * 0.8)
        car.speed *= 0.98
        
        car.x += Math.cos(car.angle) * car.speed
        car.y += Math.sin(car.angle) * car.speed
        
        // Keep AI cars in bounds
        car.x = Math.max(20, Math.min(this.canvas.width - 20, car.x))
        car.y = Math.max(20, Math.min(this.canvas.height - 20, car.y))
      }
    })
  }

  private getNextCheckpoint() {
    return this.checkpoints.find(checkpoint => !checkpoint.passed)
  }

  private checkObstacleCollisions() {
    this.obstacles.forEach(obstacle => {
      const dx = this.playerPosition.x - obstacle.x
      const dy = this.playerPosition.y - obstacle.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      
      if (distance < 30) {
        // Collision detected
        this.speed *= 0.3 // Slow down significantly
        this.addCrashParticles(obstacle.x, obstacle.y)
        
        if (this.audioSystem) {
          this.audioSystem.playSound('crash')
        }
        
        // Move obstacle slightly to prevent getting stuck
        obstacle.x += dx * 0.1
        obstacle.y += dy * 0.1
      }
    })
  }

  private checkCheckpoints() {
    this.checkpoints.forEach((checkpoint, index) => {
      if (checkpoint.passed) return
      
      const dx = this.playerPosition.x - checkpoint.x
      const dy = this.playerPosition.y - checkpoint.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      
      if (distance < 40) {
        checkpoint.passed = true
        this.addCheckpointParticles(checkpoint.x, checkpoint.y)
        
        if (this.audioSystem) {
          this.audioSystem.playSound('checkpoint')
        }
        
        // Check if lap completed
        if (index === this.checkpoints.length - 1) {
          this.currentLap++
          // Reset all checkpoints except the first one
          this.checkpoints.forEach((cp, i) => {
            cp.passed = i === 0
          })
          
          if (this.audioSystem) {
            this.audioSystem.playSound('lap_complete')
          }
        }
      }
    })
  }

  private addEngineParticles() {
    if (Math.random() < 0.3) {
      const angle = this.playerPosition.angle + Math.PI + (Math.random() - 0.5) * 0.5
      this.particles.push({
        x: this.playerPosition.x - Math.cos(this.playerPosition.angle) * 20,
        y: this.playerPosition.y - Math.sin(this.playerPosition.angle) * 20,
        vx: Math.cos(angle) * 2,
        vy: Math.sin(angle) * 2,
        life: 30,
        color: this.selectedVehicle?.color || '#ff4444'
      })
    }
  }

  private addCrashParticles(x: number, y: number) {
    for (let i = 0; i < 10; i++) {
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8,
        life: 60,
        color: '#ff8800'
      })
    }
  }

  private addCheckpointParticles(x: number, y: number) {
    for (let i = 0; i < 15; i++) {
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        life: 40,
        color: '#00ff88'
      })
    }
  }

  private updateParticles() {
    this.particles = this.particles.filter(particle => {
      particle.x += particle.vx
      particle.y += particle.vy
      particle.vx *= 0.98
      particle.vy *= 0.98
      particle.life--
      return particle.life > 0
    })
  }

  private render() {
    // Clear canvas
    this.ctx.fillStyle = this.getTrackBackgroundColor()
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)

    // Draw track elements
    this.drawTrack()
    this.drawCheckpoints()
    this.drawObstacles()
    
    // Draw AI cars
    this.aiCars.forEach(car => {
      this.drawVehicle(car.x, car.y, car.angle, car.vehicle.emoji, car.vehicle.color)
    })
    
    // Draw player
    if (this.selectedVehicle) {
      this.drawVehicle(
        this.playerPosition.x, 
        this.playerPosition.y, 
        this.playerPosition.angle, 
        this.selectedVehicle.emoji,
        this.selectedVehicle.color
      )
    }

    // Draw particles
    this.drawParticles()

    // Draw UI
    this.drawUI()

    // Draw countdown
    if (!this.isRaceStarted && this.countdown > 0) {
      this.drawCountdown()
    }
  }

  private getTrackBackgroundColor(): string {
    if (!this.selectedTrack) return '#333333'
    
    switch (this.selectedTrack.theme) {
      case 'cyberpunk': return '#1a1a2e'
      case 'desert': return '#d4a574'
      case 'forest': return '#2d5016'
      case 'space': return '#0f0f23'
      case 'beach': return '#f4e4bc'
      case 'volcano': return '#4a1a1a'
      default: return '#333333'
    }
  }

  private drawTrack() {
    // Draw track outline
    this.ctx.strokeStyle = '#666666'
    this.ctx.lineWidth = 4
    this.ctx.setLineDash([10, 5])
    
    this.ctx.beginPath()
    const centerX = this.canvas.width / 2
    const centerY = this.canvas.height / 2
    const radius = Math.min(this.canvas.width, this.canvas.height) * 0.3
    
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    this.ctx.stroke()
    this.ctx.setLineDash([])
  }

  private drawCheckpoints() {
    this.checkpoints.forEach((checkpoint, index) => {
      this.ctx.fillStyle = checkpoint.passed ? '#00ff88' : '#ffaa00'
      this.ctx.beginPath()
      this.ctx.arc(checkpoint.x, checkpoint.y, 15, 0, Math.PI * 2)
      this.ctx.fill()
      
      // Draw checkpoint number
      this.ctx.fillStyle = '#000000'
      this.ctx.font = '12px Arial'
      this.ctx.textAlign = 'center'
      this.ctx.fillText((index + 1).toString(), checkpoint.x, checkpoint.y + 4)
    })
  }

  private drawObstacles() {
    this.obstacles.forEach(obstacle => {
      this.ctx.font = '24px Arial'
      this.ctx.textAlign = 'center'
      this.ctx.fillText(obstacle.type, obstacle.x, obstacle.y)
    })
  }

  private drawVehicle(x: number, y: number, angle: number, emoji: string, color: string) {
    this.ctx.save()
    this.ctx.translate(x, y)
    this.ctx.rotate(angle)
    
    // Draw vehicle shadow
    this.ctx.fillStyle = 'rgba(0,0,0,0.3)'
    this.ctx.fillRect(-15, -8, 30, 16)
    
    // Draw vehicle body
    this.ctx.fillStyle = color
    this.ctx.fillRect(-12, -6, 24, 12)
    
    // Draw vehicle emoji
    this.ctx.font = '20px Arial'
    this.ctx.textAlign = 'center'
    this.ctx.fillText(emoji, 0, 6)
    
    this.ctx.restore()
  }

  private drawParticles() {
    this.particles.forEach(particle => {
      const alpha = particle.life / 60
      this.ctx.fillStyle = particle.color + Math.floor(alpha * 255).toString(16).padStart(2, '0')
      this.ctx.beginPath()
      this.ctx.arc(particle.x, particle.y, 3, 0, Math.PI * 2)
      this.ctx.fill()
    })
  }

  private drawUI() {
    // Draw race info
    this.ctx.fillStyle = '#ffffff'
    this.ctx.font = '16px Arial'
    this.ctx.textAlign = 'left'
    
    this.ctx.fillText(`Lap: ${this.currentLap}/${this.selectedTrack?.laps || 3}`, 10, 30)
    this.ctx.fillText(`Time: ${this.raceTime.toFixed(1)}s`, 10, 50)
    this.ctx.fillText(`Speed: ${Math.abs(this.speed).toFixed(1)}`, 10, 70)
    
    // Draw minimap
    this.drawMinimap()
    
    // Draw speedometer
    this.drawSpeedometer()
  }

  private drawMinimap() {
    const mapSize = 100
    const mapX = this.canvas.width - mapSize - 10
    const mapY = 10
    
    // Draw minimap background
    this.ctx.fillStyle = 'rgba(0,0,0,0.7)'
    this.ctx.fillRect(mapX, mapY, mapSize, mapSize)
    
    // Draw track on minimap
    this.ctx.strokeStyle = '#666666'
    this.ctx.lineWidth = 2
    this.ctx.beginPath()
    this.ctx.arc(mapX + mapSize/2, mapY + mapSize/2, mapSize/3, 0, Math.PI * 2)
    this.ctx.stroke()
    
    // Draw player position on minimap
    const playerMapX = mapX + (this.playerPosition.x / this.canvas.width) * mapSize
    const playerMapY = mapY + (this.playerPosition.y / this.canvas.height) * mapSize
    
    this.ctx.fillStyle = '#00ff00'
    this.ctx.beginPath()
    this.ctx.arc(playerMapX, playerMapY, 3, 0, Math.PI * 2)
    this.ctx.fill()
    
    // Draw AI cars on minimap
    this.aiCars.forEach(car => {
      const carMapX = mapX + (car.x / this.canvas.width) * mapSize
      const carMapY = mapY + (car.y / this.canvas.height) * mapSize
      
      this.ctx.fillStyle = '#ff0000'
      this.ctx.beginPath()
      this.ctx.arc(carMapX, carMapY, 2, 0, Math.PI * 2)
      this.ctx.fill()
    })
  }

  private drawSpeedometer() {
    const centerX = this.canvas.width - 80
    const centerY = this.canvas.height - 80
    const radius = 40
    
    // Draw speedometer background
    this.ctx.fillStyle = 'rgba(0,0,0,0.7)'
    this.ctx.beginPath()
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    this.ctx.fill()
    
    // Draw speed arc
    const speedRatio = Math.abs(this.speed) / this.maxSpeed
    const startAngle = -Math.PI / 2
    const endAngle = startAngle + (speedRatio * Math.PI * 1.5)
    
    this.ctx.strokeStyle = speedRatio > 0.8 ? '#ff4444' : '#44ff44'
    this.ctx.lineWidth = 6
    this.ctx.beginPath()
    this.ctx.arc(centerX, centerY, radius - 10, startAngle, endAngle)
    this.ctx.stroke()
    
    // Draw speed text
    this.ctx.fillStyle = '#ffffff'
    this.ctx.font = '12px Arial'
    this.ctx.textAlign = 'center'
    this.ctx.fillText(Math.floor(Math.abs(this.speed) * 10).toString(), centerX, centerY + 4)
  }

  private drawCountdown() {
    this.ctx.fillStyle = 'rgba(0,0,0,0.8)'
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)
    
    this.ctx.fillStyle = '#ffffff'
    this.ctx.font = '72px Arial'
    this.ctx.textAlign = 'center'
    
    if (this.countdown > 0) {
      this.ctx.fillText(this.countdown.toString(), this.canvas.width / 2, this.canvas.height / 2)
    } else {
      this.ctx.fillText('GO!', this.canvas.width / 2, this.canvas.height / 2)
    }
  }

  private finishRace() {
    this.gameState = 'finished'
    
    if (this.animationId) {
      cancelAnimationFrame(this.animationId)
    }
    
    // Calculate final position (simplified)
    const playerTime = this.raceTime
    let position = 1
    
    // Simple position calculation based on time
    this.aiCars.forEach(() => {
      if (Math.random() < 0.3) { // 30% chance AI finishes before player
        position++
      }
    })
    
    if (this.onRaceComplete) {
      this.onRaceComplete(playerTime, position)
    }
    
    if (this.audioSystem) {
      this.audioSystem.playSound('race_finish')
    }
  }

  setRaceCompleteCallback(callback: (time: number, position: number) => void) {
    this.onRaceComplete = callback
  }

  pauseRace() {
    this.gameState = 'paused'
    if (this.animationId) {
      cancelAnimationFrame(this.animationId)
    }
  }

  resumeRace() {
    if (this.gameState === 'paused') {
      this.gameState = 'racing'
      this.gameLoop()
    }
  }

  cleanup() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId)
    }
  }

  getGameState() {
    return this.gameState
  }

  getCurrentStats() {
    return {
      lap: this.currentLap,
      totalLaps: this.selectedTrack?.laps || 3,
      time: this.raceTime,
      speed: Math.abs(this.speed),
      maxSpeed: this.maxSpeed
    }
  }
}

// Enhanced Audio System with racing sounds
class AudioSystem {
  private audioContext: AudioContext | null = null
  private masterGain: GainNode | null = null
  private musicGain: GainNode | null = null
  private effectsGain: GainNode | null = null
  private analyser: AnalyserNode | null = null
  private isPlaying = false
  private oscillators: OscillatorNode[] = []
  private currentChord = 0
  private tempo = 120
  private musicStyle = 'Ambient'
  private audioData = new Uint8Array(128)
  private bassLevel = 0
  private midLevel = 0
  private trebleLevel = 0
  private beatDetected = false
  private lastBeatTime = 0
  private beatThreshold = 0.15
  private beatHoldTime = 200
  private beatDecayRate = 0.97
  private beatCutOff = 0
  private onBeat: (() => void) | null = null
  private loopId: number | null = null
  private reverb: ConvolverNode | null = null
  private delay: DelayNode | null = null
  private compressor: DynamicsCompressorNode | null = null
  private filter: BiquadFilterNode | null = null
  private lfo: OscillatorNode | null = null
  private musicVolume = 0.5
  private effectsVolume = 0.5

  constructor() {
    if (typeof window !== 'undefined') {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      this.setupAudioGraph()
    }
  }

  private setupAudioGraph() {
    if (!this.audioContext) return

    // Create main nodes
    this.masterGain = this.audioContext.createGain()
    this.musicGain = this.audioContext.createGain()
    this.effectsGain = this.audioContext.createGain()
    this.analyser = this.audioContext.createAnalyser()
    this.compressor = this.audioContext.createDynamicsCompressor()
    this.filter = this.audioContext.createBiquadFilter()
    this.delay = this.audioContext.createDelay(1.0)
    
    // Configure analyser
    this.analyser.fftSize = 256
    this.analyser.smoothingTimeConstant = 0.8
    
    // Configure compressor
    this.compressor.threshold.value = -24
    this.compressor.knee.value = 30
    this.compressor.ratio.value = 12
    this.compressor.attack.value = 0.003
    this.compressor.release.value = 0.25
    
    // Configure filter
    this.filter.type = 'lowpass'
    this.filter.frequency.value = 1000
    this.filter.Q.value = 1
    
    // Configure delay
    this.delay.delayTime.value = 0.3
    
    // Create LFO for filter modulation
    this.lfo = this.audioContext.createOscillator()
    this.lfo.type = 'sine'
    this.lfo.frequency.value = 0.2
    const lfoGain = this.audioContext.createGain()
    lfoGain.gain.value = 300
    this.lfo.connect(lfoGain)
    lfoGain.connect(this.filter.frequency)
    this.lfo.start()
    
    // Create reverb impulse response
    this.createReverb()
    
    // Set initial volumes
    this.musicGain.gain.value = this.musicVolume
    this.effectsGain.gain.value = this.effectsVolume
    this.masterGain.gain.value = 1.0
    
    // Connect audio graph
    this.musicGain.connect(this.filter)
    this.filter.connect(this.delay)
    this.delay.connect(this.compressor)
    this.filter.connect(this.compressor)
    this.compressor.connect(this.analyser)
    this.analyser.connect(this.masterGain)
    this.effectsGain.connect(this.masterGain)
    this.masterGain.connect(this.audioContext.destination)
    
    // Start audio analysis loop
    this.startAnalysis()
  }

  private async createReverb() {
    if (!this.audioContext) return
    
    // Create impulse response for reverb
    const sampleRate = this.audioContext.sampleRate
    const length = 2 * sampleRate // 2 seconds
    const impulse = this.audioContext.createBuffer(2, length, sampleRate)
    
    for (let channel = 0; channel < 2; channel++) {
      const impulseData = impulse.getChannelData(channel)
      for (let i = 0; i < length; i++) {
        // Exponential decay
        impulseData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 1.5)
      }
    }
    
    this.reverb = this.audioContext.createConvolver()
    this.reverb.buffer = impulse
    
    // Connect reverb to audio graph
    this.delay.connect(this.reverb)
    this.reverb.connect(this.compressor)
  }

  private startAnalysis() {
    if (!this.analyser) return
    
    const analyzeAudio = () => {
      if (!this.analyser) return
      
      // Get frequency data
      this.analyser.getByteFrequencyData(this.audioData)
      
      // Calculate levels for different frequency bands
      let bassSum = 0
      let midSum = 0
      let trebleSum = 0
      
      // Bass: 0-120Hz (roughly first 10% of bins)
      for (let i = 0; i < this.audioData.length * 0.1; i++) {
        bassSum += this.audioData[i]
      }
      
      // Mids: 120Hz-2.5kHz (roughly next 40% of bins)
      for (let i = Math.floor(this.audioData.length * 0.1); i < this.audioData.length * 0.5; i++) {
        midSum += this.audioData[i]
      }
      
      // Treble: 2.5kHz+ (roughly last 50% of bins)
      for (let i = Math.floor(this.audioData.length * 0.5); i < this.audioData.length; i++) {
        trebleSum += this.audioData[i]
      }
      
      // Normalize values to 0-1
      this.bassLevel = bassSum / (this.audioData.length * 0.1 * 255)
      this.midLevel = midSum / (this.audioData.length * 0.4 * 255)
      this.trebleLevel = trebleSum / (this.audioData.length * 0.5 * 255)
      
      // Beat detection
      if (this.bassLevel > this.beatCutOff && this.bassLevel > this.beatThreshold) {
        this.onBeatDetected()
        this.beatCutOff = this.bassLevel * 1.1
        this.lastBeatTime = Date.now()
      } else {
        if (this.beatCutOff > this.beatThreshold) {
          this.beatCutOff *= this.beatDecayRate
          this.beatCutOff = Math.max(this.beatCutOff, this.beatThreshold)
        }
        
        if (Date.now() - this.lastBeatTime > this.beatHoldTime) {
          this.beatDetected = false
        }
      }
      
      this.loopId = requestAnimationFrame(analyzeAudio)
    }
    
    this.loopId = requestAnimationFrame(analyzeAudio)
  }

  private stopAnalysis() {
    if (this.loopId !== null) {
      cancelAnimationFrame(this.loopId)
      this.loopId = null
    }
  }

  private onBeatDetected() {
    this.beatDetected = true
    if (this.onBeat) {
      this.onBeat()
    }
  }

  setOnBeatCallback(callback: () => void) {
    this.onBeat = callback
  }

  getAudioLevels() {
    return {
      bass: this.bassLevel,
      mid: this.midLevel,
      treble: this.trebleLevel,
      beat: this.beatDetected
    }
  }

  setMusicStyle(style: string) {
    this.musicStyle = style
    if (this.isPlaying) {
      this.stopBackgroundMusic()
      this.startBackgroundMusic()
    }
  }

  setMusicVolume(volume: number) {
    this.musicVolume = volume
    if (this.musicGain) {
      this.musicGain.gain.setValueAtTime(volume, this.audioContext?.currentTime || 0)
    }
  }

  setEffectsVolume(volume: number) {
    this.effectsVolume = volume
    if (this.effectsGain) {
      this.effectsGain.gain.setValueAtTime(volume, this.audioContext?.currentTime || 0)
    }
  }

  async startBackgroundMusic() {
    if (!this.audioContext || this.isPlaying) return

    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume()
    }

    this.isPlaying = true
    
    switch (this.musicStyle) {
      case 'Ambient':
        this.playAmbientMusic()
        break
      case 'Synthwave':
        this.playSynthwaveMusic()
        break
      case 'Chiptune':
        this.playChiptuneMusic()
        break
      case 'Lo-Fi':
        this.playLofiMusic()
        break
      case 'Techno':
        this.playTechnoMusic()
        break
      case 'Cosmic':
        this.playCosmicMusic()
        break
      case 'Racing':
        this.playRacingMusic()
        break
      default:
        this.playAmbientMusic()
    }
  }

  stopBackgroundMusic() {
    this.isPlaying = false
    this.oscillators.forEach(osc => {
      try {
        osc.stop()
      } catch (e) {
        // Oscillator might already be stopped
      }
    })
    this.oscillators = []
  }

  private playRacingMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 140
    
    // High-energy racing music with driving bass and synth leads
    const bassNotes = [
      130.81, 130.81, 146.83, 164.81, // C, C, D, E
      130.81, 130.81, 146.83, 164.81,
      110.00, 110.00, 123.47, 130.81, // A, A, B, C
      110.00, 110.00, 123.47, 130.81
    ]
    
    const leadNotes = [
      523.25, 587.33, 659.25, 698.46, // C5, D5, E5, F5
      783.99, 698.46, 659.25, 587.33, // G5, F5, E5, D5
      523.25, 587.33, 659.25, 698.46,
      783.99, 880.00, 783.99, 698.46
    ]
    
    let bassIndex = 0
    let leadIndex = 0
    
    const playBass = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const note = bassNotes[bassIndex % bassNotes.length]
      
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      const filter = this.audioContext.createBiquadFilter()
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
      osc.type = 'sawtooth'
      
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(300, this.audioContext.currentTime)
      filter.Q.setValueAtTime(8, this.audioContext.currentTime)
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.4)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 0.4)
      this.oscillators.push(osc)
      
      bassIndex++
      
      if (this.isPlaying) {
        setTimeout(playBass, (60 / this.tempo) * 0.25 * 1000) // 16th notes
      }
    }
    
    const playLead = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const note = leadNotes[leadIndex % leadNotes.length]
      
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      const filter = this.audioContext.createBiquadFilter()
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
      osc.type = 'square'
      
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(2000, this.audioContext.currentTime)
      filter.frequency.exponentialRampToValueAtTime(800, this.audioContext.currentTime + 0.3)
      filter.Q.setValueAtTime(3, this.audioContext.currentTime)
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.15, this.audioContext.currentTime + 0.05)
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.5)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 0.5)
      this.oscillators.push(osc)
      
      leadIndex++
      
      if (this.isPlaying) {
        setTimeout(playLead, (60 / this.tempo) * 0.5 * 1000) // 8th notes
      }
    }
    
    // Start both patterns
    playBass()
    setTimeout(() => {
      if (this.isPlaying) playLead()
    }, 500)
  }

  private playAmbientMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    // Chord progressions for ambient electronic music
    const chords = [
      [261.63, 329.63, 392.00], // C major
      [293.66, 369.99, 440.00], // D minor
      [329.63, 415.30, 493.88], // E minor
      [349.23, 440.00, 523.25], // F major
      [392.00, 493.88, 587.33], // G major
      [440.00, 554.37, 659.25], // A minor
    ]

    const playChord = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return

      // Clear previous oscillators
      this.oscillators.forEach(osc => {
        try {
          osc.stop()
        } catch (e) {
          // Ignore
        }
      })
      this.oscillators = []

      const chord = chords[this.currentChord % chords.length]
      
      chord.forEach((freq, index) => {
        // Main chord tones
        const osc = this.audioContext!.createOscillator()
        const gain = this.audioContext!.createGain()
        
        osc.connect(gain)
        gain.connect(this.musicGain!)

        osc.frequency.setValueAtTime(freq * 0.5, this.audioContext!.currentTime) // Lower octave
        osc.type = 'sine'
        
        gain.gain.setValueAtTime(0, this.audioContext!.currentTime)
        gain.gain.linearRampToValueAtTime(0.1, this.audioContext!.currentTime + 0.1)
        gain.gain.linearRampToValueAtTime(0.05, this.audioContext!.currentTime + 2)

        osc.start()
        osc.stop(this.audioContext!.currentTime + 4)
        this.oscillators.push(osc)

        // Add some sparkle with higher frequencies
        if (index === 0) {
          const sparkleOsc = this.audioContext!.createOscillator()
          const sparkleGain = this.audioContext!.createGain()
          
          sparkleOsc.connect(sparkleGain)
          sparkleGain.connect(this.musicGain!)
          
          sparkleOsc.frequency.setValueAtTime(freq * 4, this.audioContext!.currentTime)
          sparkleOsc.type = 'triangle'
          
          sparkleGain.gain.setValueAtTime(0, this.audioContext!.currentTime)
          sparkleGain.gain.linearRampToValueAtTime(0.02, this.audioContext!.currentTime + 0.1)
          sparkleGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext!.currentTime + 1)
          
          sparkleOsc.start()
          sparkleOsc.stop(this.audioContext!.currentTime + 1)
          this.oscillators.push(sparkleOsc)
        }
        
        // Add bass
        if (index === 0) {
          const bassOsc = this.audioContext!.createOscillator()
          const bassGain = this.audioContext!.createGain()
          
          bassOsc.connect(bassGain)
          bassGain.connect(this.musicGain!)
          
          bassOsc.frequency.setValueAtTime(freq * 0.25, this.audioContext!.currentTime) // 2 octaves lower
          bassOsc.type = 'sine'
          
          bassGain.gain.setValueAtTime(0, this.audioContext!.currentTime)
          bassGain.gain.linearRampToValueAtTime(0.15, this.audioContext!.currentTime + 0.1)
          bassGain.gain.linearRampToValueAtTime(0.05, this.audioContext!.currentTime + 3)
          
          bassOsc.start()
          bassOsc.stop(this.audioContext!.currentTime + 4)
          this.oscillators.push(bassOsc)
        }
      })

      this.currentChord++
      
      if (this.isPlaying) {
        setTimeout(playChord, (60 / this.tempo) * 4 * 1000) // 4 beats per chord
      }
    }

    playChord()
  }

  private playSynthwaveMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 100
    
    // Synthwave arpeggio patterns
    const arpeggios = [
      [261.63, 329.63, 392.00, 523.25], // C major
      [293.66, 349.23, 440.00, 587.33], // D minor
      [329.63, 392.00, 493.88, 659.25], // E minor
      [349.23, 440.00, 523.25, 698.46]  // F major
    ]
    
    // Synthwave bass line
    const bassNotes = [
      261.63 * 0.5, // C
      220.00 * 0.5, // A
      196.00 * 0.5, // G
      174.61 * 0.5  // F
    ]
    
    let currentArpIndex = 0
    let currentArpNote = 0
    let currentBassNote = 0
    
    const playArpeggio = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      // Play arpeggio note
      const arp = arpeggios[currentArpIndex % arpeggios.length]
      const note = arp[currentArpNote % arp.length]
      
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      
      osc.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
      osc.type = 'sawtooth'
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 0.01)
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 0.2)
      this.oscillators.push(osc)
      
      // Increment counters
      currentArpNote++
      if (currentArpNote % arp.length === 0) {
        currentArpNote = 0
      }
      
      // Schedule next note
      if (this.isPlaying) {
        setTimeout(playArpeggio, (60 / this.tempo) * 0.5 * 1000) // 16th notes
      }
    }
    
    const playBass = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      // Play bass note
      const note = bassNotes[currentBassNote % bassNotes.length]
      
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      const filter = this.audioContext.createBiquadFilter()
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
      osc.type = 'sawtooth'
      
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(500, this.audioContext.currentTime)
      filter.Q.setValueAtTime(5, this.audioContext.currentTime)
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.1)
      gain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 2)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 2)
      this.oscillators.push(osc)
      
      // Increment counters
      currentBassNote++
      if (currentBassNote % bassNotes.length === 0) {
        currentBassNote = 0
        currentArpIndex++
      }
      
      // Schedule next note
      if (this.isPlaying) {
        setTimeout(playBass, (60 / this.tempo) * 4 * 1000) // 1 bar
      }
    }
    
    // Start both patterns
    playArpeggio()
    playBass()
  }

  private playChiptuneMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 140
    
    // Chiptune melody
    const melody = [
      392.00, 392.00, 523.25, 392.00, 0, 493.88, 440.00, // C major melody
      392.00, 392.00, 523.25, 392.00, 0, 587.33, 523.25, // Variation
    ]
    
    // Chiptune bass
    const bass = [
      261.63, 0, 261.63, 261.63, 196.00, 0, 196.00, 196.00,
      174.61, 0, 174.61, 174.61, 196.00, 220.00, 246.94, 261.63
    ]
    
    let melodyIndex = 0
    let bassIndex = 0
    
    const playMelody = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const note = melody[melodyIndex % melody.length]
      
      if (note > 0) {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.musicGain)
        
        osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
        osc.type = 'square'
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 0.01)
        gain.gain.linearRampToValueAtTime(0.05, this.audioContext.currentTime + 0.1)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.15)
        this.oscillators.push(osc)
      }
      
      melodyIndex++
      
      if (this.isPlaying) {
        setTimeout(playMelody, (60 / this.tempo) * 1000) // Quarter notes
      }
    }
    
    const playBass = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const note = bass[bassIndex % bass.length]
      
      if (note > 0) {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.musicGain)
        
        osc.frequency.setValueAtTime(note * 0.5, this.audioContext.currentTime)
        osc.type = 'square'
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.15, this.audioContext.currentTime + 0.01)
        gain.gain.linearRampToValueAtTime(0.05, this.audioContext.currentTime + 0.2)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.25)
        this.oscillators.push(osc)
      }
      
      bassIndex++
      
      if (this.isPlaying) {
        setTimeout(playBass, (60 / this.tempo) * 0.5 * 1000) // Eighth notes
      }
    }
    
    // Start both patterns
    playMelody()
    playBass()
  }

  private playLofiMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 85
    
    // Lo-Fi chord progression
    const chords = [
      [261.63, 329.63, 392.00, 493.88], // Cmaj7
      [246.94, 311.13, 392.00, 466.16], // Bmin7
      [220.00, 277.18, 349.23, 440.00], // Amin7
      [196.00, 246.94, 311.13, 392.00]  // Gmin7
    ]
    
    // Lo-Fi drum pattern (just timing)
    const drumPattern = [
      { type: 'kick', time: 0 },
      { type: 'snare', time: 0.5 },
      { type: 'kick', time: 1 },
      { type: 'snare', time: 1.5 },
      { type: 'kick', time: 2 },
      { type: 'snare', time: 2.5 },
      { type: 'kick', time: 3 },
      { type: 'snare', time: 3.5 }
    ]
    
    let currentChord = 0
    
    const playChord = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const chord = chords[currentChord % chords.length]
      
      // Play chord with jazzy voicing
      chord.forEach((note, i) => {
        const osc = this.audioContext!.createOscillator()
        const gain = this.audioContext!.createGain()
        const filter = this.audioContext!.createBiquadFilter()
        
        osc.connect(filter)
        filter.connect(gain)
        gain.connect(this.musicGain!)
        
        osc.frequency.setValueAtTime(note, this.audioContext!.currentTime)
        osc.type = i === 0 ? 'sine' : 'triangle'
        
        filter.type = 'lowpass'
        filter.frequency.setValueAtTime(1500, this.audioContext!.currentTime)
        filter.Q.setValueAtTime(1, this.audioContext!.currentTime)
        
        gain.gain.setValueAtTime(0, this.audioContext!.currentTime)
        gain.gain.linearRampToValueAtTime(i === 0 ? 0.15 : 0.08, this.audioContext!.currentTime + 0.1)
        gain.gain.linearRampToValueAtTime(0.001, this.audioContext!.currentTime + 3.8)
        
        osc.start()
        osc.stop(this.audioContext!.currentTime + 4)
        this.oscillators.push(osc)
      })
      
      // Play melody note
      const melodyNote = chord[chord.length - 1] * 2
      setTimeout(() => {
        if (!this.isPlaying || !this.audioContext || !this.musicGain) return
        
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        osc.connect(filter)
        filter.connect(gain)
        gain.connect(this.musicGain)
        
        osc.frequency.setValueAtTime(melodyNote, this.audioContext.currentTime)
        osc.type = 'sine'
        
        filter.type = 'lowpass'
        filter.frequency.setValueAtTime(2000, this.audioContext.currentTime)
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 0.1)
        gain.gain.linearRampToValueAtTime(0.001, this.audioContext.currentTime + 1)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 1)
        this.oscillators.push(osc)
      }, (60 / this.tempo) * 2 * 1000)
      
      // Play drums
      drumPattern.forEach(drum => {
        setTimeout(() => {
          if (!this.isPlaying || !this.audioContext || !this.musicGain) return
          this.playDrumSound(drum.type)
        }, (60 / this.tempo) * drum.time * 1000)
      })
      
      currentChord++
      
      if (this.isPlaying) {
        setTimeout(playChord, (60 / this.tempo) * 4 * 1000) // 1 bar
      }
    }
    
    playChord()
  }

  private playTechnoMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 130
    
    // Techno bass sequence
    const bassSequence = [
      261.63, 261.63, 261.63, 233.08,
      220.00, 220.00, 220.00, 196.00,
      185.00, 185.00, 196.00, 220.00,
      233.08, 233.08, 246.94, 261.63
    ]
    
    // Techno hi-hat pattern (just timing)
    const hihatPattern = [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]
    
    // Techno kick pattern (just timing)
    const kickPattern = [0, 1, 2, 3]
    
    let bassIndex = 0
    
    const playBass = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      const note = bassSequence[bassIndex % bassSequence.length]
      
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      const filter = this.audioContext.createBiquadFilter()
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note, this.audioContext.currentTime)
      osc.type = 'sawtooth'
      
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(500, this.audioContext.currentTime)
      filter.frequency.linearRampToValueAtTime(100, this.audioContext.currentTime + 0.2)
      filter.Q.setValueAtTime(10, this.audioContext.currentTime)
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.01)
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 0.3)
      this.oscillators.push(osc)
      
      bassIndex++
      
      if (this.isPlaying) {
        setTimeout(playBass, (60 / this.tempo) * 0.25 * 1000) // 16th notes
      }
    }
    
    const playDrums = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      // Play kick pattern
      kickPattern.forEach(time => {
        setTimeout(() => {
          if (!this.isPlaying) return
          this.playDrumSound('kick')
        }, (60 / this.tempo) * time * 1000)
      })
      
      // Play hi-hat pattern
      hihatPattern.forEach(time => {
        setTimeout(() => {
          if (!this.isPlaying) return
          this.playDrumSound('hihat')
        }, (60 / this.tempo) * time * 1000)
      })
      
      if (this.isPlaying) {
        setTimeout(playDrums, (60 / this.tempo) * 4 * 1000) // 1 bar
      }
    }
    
    // Start patterns
    playBass()
    playDrums()
  }

  private playCosmicMusic() {
    if (!this.audioContext || !this.musicGain || !this.isPlaying) return

    this.tempo = 60
    
    // Cosmic drone notes
    const droneNotes = [
      261.63, // C
      293.66, // D
      329.63, // E
      349.23, // F
      392.00  // G
    ]
    
    // Play cosmic drone
    const playDrone = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      // Select random note
      const note = droneNotes[Math.floor(Math.random() * droneNotes.length)]
      
      // Create drone oscillator
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()
      const filter = this.audioContext.createBiquadFilter()
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(this.musicGain)
      
      osc.frequency.setValueAtTime(note * (Math.random() < 0.5 ? 0.5 : 1), this.audioContext.currentTime)
      osc.type = ['sine', 'triangle'][Math.floor(Math.random() * 2)] as OscillatorType
      
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(500 + Math.random() * 1000, this.audioContext.currentTime)
      filter.Q.setValueAtTime(10, this.audioContext.currentTime)
      
      gain.gain.setValueAtTime(0, this.audioContext.currentTime)
      gain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 2)
      gain.gain.linearRampToValueAtTime(0, this.audioContext.currentTime + 10)
      
      osc.start()
      osc.stop(this.audioContext.currentTime + 10)
      this.oscillators.push(osc)
      
      // Schedule next drone
      if (this.isPlaying) {
        setTimeout(playDrone, 2000 + Math.random() * 3000) // Random timing
      }
    }
    
    // Play cosmic pads
    const playPad = () => {
      if (!this.isPlaying || !this.audioContext || !this.musicGain) return
      
      // Select random chord
      const rootNote = droneNotes[Math.floor(Math.random() * droneNotes.length)]
      const chord = [
        rootNote,
        rootNote * 1.5, // Perfect fifth
        rootNote * 2    // Octave
      ]
      
      // Play chord
      chord.forEach(note => {
        const osc = this.audioContext!.createOscillator()
        const gain = this.audioContext!.createGain()
        
        osc.connect(gain)
        gain.connect(this.musicGain!)
        
        osc.frequency.setValueAtTime(note, this.audioContext!.currentTime)
        osc.type = 'sine'
        
        gain.gain.setValueAtTime(0, this.audioContext!.currentTime)
        gain.gain.linearRampToValueAtTime(0.05, this.audioContext!.currentTime + 4)
        gain.gain.linearRampToValueAtTime(0, this.audioContext!.currentTime + 15)
        
        osc.start()
        osc.stop(this.audioContext!.currentTime + 15)
        this.oscillators.push(osc)
      })
      
      // Schedule next pad
      if (this.isPlaying) {
        setTimeout(playPad, 8000 + Math.random() * 5000) // Random timing
      }
    }
    
    // Start cosmic sounds
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        if (this.isPlaying) playDrone()
      }, i * 1000)
    }
    
    for (let i = 0; i < 2; i++) {
      setTimeout(() => {
        if (this.isPlaying) playPad()
      }, i * 4000)
    }
  }

  private playDrumSound(type: string) {
    if (!this.audioContext || !this.effectsGain) return
    
    switch (type) {
      case 'kick': {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(150, this.audioContext.currentTime)
        osc.frequency.exponentialRampToValueAtTime(40, this.audioContext.currentTime + 0.2)
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.3)
        break
      }
      
      case 'snare': {
        const noise = this.audioContext.createBufferSource()
        const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.2, this.audioContext.sampleRate)
        const noiseData = noiseBuffer.getChannelData(0)
        
        for (let i = 0; i < noiseBuffer.length; i++) {
          noiseData[i] = Math.random() * 2 - 1
        }
        
        noise.buffer = noiseBuffer
        
        const noiseGain = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        noise.connect(filter)
        filter.connect(noiseGain)
        noiseGain.connect(this.effectsGain)
        
        filter.type = 'highpass'
        filter.frequency.value = 1000
        
        noiseGain.gain.setValueAtTime(0, this.audioContext.currentTime)
        noiseGain.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.01)
        noiseGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)
        
        noise.start()
        noise.stop(this.audioContext.currentTime + 0.2)
        break
      }
      
      case 'hihat': {
        const noise = this.audioContext.createBufferSource()
        const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.1, this.audioContext.sampleRate)
        const noiseData = noiseBuffer.getChannelData(0)
        
        for (let i = 0; i < noiseBuffer.length; i++) {
          noiseData[i] = Math.random() * 2 - 1
        }
        
        noise.buffer = noiseBuffer
        
        const noiseGain = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        noise.connect(filter)
        filter.connect(noiseGain)
        noiseGain.connect(this.effectsGain)
        
        filter.type = 'highpass'
        filter.frequency.value = 7000
        
        noiseGain.gain.setValueAtTime(0, this.audioContext.currentTime)
        noiseGain.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 0.01)
        noiseGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.05)
        
        noise.start()
        noise.stop(this.audioContext.currentTime + 0.05)
        break
      }
    }
  }

  async playSound(type: string) {
    if (!this.audioContext || !this.effectsGain) return

    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume()
    }

    switch (type) {
      case 'click': {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(800, this.audioContext.currentTime)
        osc.frequency.exponentialRampToValueAtTime(400, this.audioContext.currentTime + 0.1)
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.1)
        osc.type = 'sine'
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.1)
        break
      }
      
      case 'camera': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        
        osc1.connect(gain1)
        osc2.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(440, this.audioContext.currentTime)
        osc1.frequency.exponentialRampToValueAtTime(880, this.audioContext.currentTime + 0.3)
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        osc1.type = 'square'
        
        osc2.frequency.setValueAtTime(660, this.audioContext.currentTime)
        osc2.frequency.exponentialRampToValueAtTime(1320, this.audioContext.currentTime + 0.2)
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime + 0.1)
        gain2.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.15)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        osc2.type = 'triangle'
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.3)
        osc2.stop(this.audioContext.currentTime + 0.3)
        break
      }
      
      case 'capture': {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        osc.connect(filter)
        filter.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(1000, this.audioContext.currentTime)
        osc.frequency.exponentialRampToValueAtTime(500, this.audioContext.currentTime + 0.2)
        
        filter.type = 'lowpass'
        filter.frequency.setValueAtTime(5000, this.audioContext.currentTime)
        filter.frequency.exponentialRampToValueAtTime(800, this.audioContext.currentTime + 0.2)
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.4, this.audioContext.currentTime + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)
        
        osc.type = 'sawtooth'
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.2)
        
        // Add camera shutter sound
        setTimeout(() => {
          const noise = this.audioContext!.createBufferSource()
          const noiseBuffer = this.audioContext!.createBuffer(1, this.audioContext!.sampleRate * 0.1, this.audioContext!.sampleRate)
          const noiseData = noiseBuffer.getChannelData(0)
          
          for (let i = 0; i < noiseBuffer.length; i++) {
            noiseData[i] = Math.random() * 2 - 1
          }
          
          noise.buffer = noiseBuffer
          
          const noiseGain = this.audioContext!.createGain()
          const noiseFilter = this.audioContext!.createBiquadFilter()
          
          noise.connect(noiseFilter)
          noiseFilter.connect(noiseGain)
          noiseGain.connect(this.effectsGain!)
          
          noiseFilter.type = 'highpass'
          noiseFilter.frequency.value = 2000
          
          noiseGain.gain.setValueAtTime(0, this.audioContext!.currentTime)
          noiseGain.gain.linearRampToValueAtTime(0.3, this.audioContext!.currentTime + 0.01)
          noiseGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext!.currentTime + 0.05)
          
          noise.start()
          noise.stop(this.audioContext!.currentTime + 0.05)
        }, 100)
        break
      }
      
      case 'mismatch': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        
        osc1.connect(gain1)
        osc2.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(300, this.audioContext.currentTime)
        osc1.frequency.exponentialRampToValueAtTime(600, this.audioContext.currentTime + 0.15)
        osc1.frequency.exponentialRampToValueAtTime(200, this.audioContext.currentTime + 0.3)
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        osc1.type = 'triangle'
        
        osc2.frequency.setValueAtTime(450, this.audioContext.currentTime)
        osc2.frequency.exponentialRampToValueAtTime(900, this.audioContext.currentTime + 0.1)
        osc2.frequency.exponentialRampToValueAtTime(300, this.audioContext.currentTime + 0.2)
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime + 0.05)
        gain2.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.1)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.25)
        osc2.type = 'sine'
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.3)
        osc2.stop(this.audioContext.currentTime + 0.25)
        break
      }
      
      case 'reset': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        
        osc1.connect(gain1)
        osc2.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(600, this.audioContext.currentTime)
        osc1.frequency.exponentialRampToValueAtTime(300, this.audioContext.currentTime + 0.1)
        osc1.frequency.exponentialRampToValueAtTime(900, this.audioContext.currentTime + 0.2)
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)
        osc1.type = 'square'
        
        osc2.frequency.setValueAtTime(1200, this.audioContext.currentTime + 0.1)
        osc2.frequency.exponentialRampToValueAtTime(600, this.audioContext.currentTime + 0.2)
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime + 0.1)
        gain2.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.15)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.25)
        osc2.type = 'sine'
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.2)
        osc2.stop(this.audioContext.currentTime + 0.25)
        break
      }
      
      case 'emoji': {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(500 + Math.random() * 500, this.audioContext.currentTime)
        osc.frequency.exponentialRampToValueAtTime(800 + Math.random() * 400, this.audioContext.currentTime + 0.05)
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.05)
        osc.type = 'sine'
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.05)
        break
      }
      
      case 'theme': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        
        osc1.connect(gain1)
        osc2.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(800, this.audioContext.currentTime)
        osc1.frequency.exponentialRampToValueAtTime(1200, this.audioContext.currentTime + 0.1)
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.01)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.15)
        osc1.type = 'sine'
        
        osc2.frequency.setValueAtTime(600, this.audioContext.currentTime + 0.05)
        osc2.frequency.exponentialRampToValueAtTime(900, this.audioContext.currentTime + 0.15)
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime + 0.05)
        gain2.gain.linearRampToValueAtTime(0.15, this.audioContext.currentTime + 0.1)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)
        osc2.type = 'triangle'
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.15)
        osc2.stop(this.audioContext.currentTime + 0.2)
        break
      }

      // Racing-specific sound effects
      case 'engine': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        osc1.connect(filter)
        osc2.connect(filter)
        filter.connect(gain1)
        filter.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(80, this.audioContext.currentTime)
        osc1.frequency.exponentialRampToValueAtTime(200, this.audioContext.currentTime + 0.5)
        osc1.type = 'sawtooth'
        
        osc2.frequency.setValueAtTime(160, this.audioContext.currentTime)
        osc2.frequency.exponentialRampToValueAtTime(400, this.audioContext.currentTime + 0.5)
        osc2.type = 'square'
        
        filter.type = 'lowpass'
        filter.frequency.setValueAtTime(800, this.audioContext.currentTime)
        filter.Q.setValueAtTime(5, this.audioContext.currentTime)
        
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.1)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.8)
        
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain2.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.1)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.8)
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.8)
        osc2.stop(this.audioContext.currentTime + 0.8)
        break
      }
      
      case 'crash': {
        const noise = this.audioContext.createBufferSource()
        const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.5, this.audioContext.sampleRate)
        const noiseData = noiseBuffer.getChannelData(0)
        
        for (let i = 0; i < noiseBuffer.length; i++) {
          noiseData[i] = Math.random() * 2 - 1
        }
        
        noise.buffer = noiseBuffer
        
        const noiseGain = this.audioContext.createGain()
        const filter = this.audioContext.createBiquadFilter()
        
        noise.connect(filter)
        filter.connect(noiseGain)
        noiseGain.connect(this.effectsGain)
        
        filter.type = 'bandpass'
        filter.frequency.value = 500
        filter.Q.value = 2
        
        noiseGain.gain.setValueAtTime(0, this.audioContext.currentTime)
        noiseGain.gain.linearRampToValueAtTime(0.5, this.audioContext.currentTime + 0.01)
        noiseGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.5)
        
        noise.start()
        noise.stop(this.audioContext.currentTime + 0.5)
        break
      }
      
      case 'checkpoint': {
        const osc1 = this.audioContext.createOscillator()
        const osc2 = this.audioContext.createOscillator()
        const gain1 = this.audioContext.createGain()
        const gain2 = this.audioContext.createGain()
        
        osc1.connect(gain1)
        osc2.connect(gain2)
        gain1.connect(this.effectsGain)
        gain2.connect(this.effectsGain)
        
        osc1.frequency.setValueAtTime(523.25, this.audioContext.currentTime) // C5
        osc1.frequency.exponentialRampToValueAtTime(1046.5, this.audioContext.currentTime + 0.2) // C6
        osc1.type = 'sine'
        
        osc2.frequency.setValueAtTime(659.25, this.audioContext.currentTime) // E5
        osc2.frequency.exponentialRampToValueAtTime(1318.5, this.audioContext.currentTime + 0.2) // E6
        osc2.type = 'triangle'
        
        gain1.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain1.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.05)
        gain1.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        
        gain2.gain.setValueAtTime(0, this.audioContext.currentTime + 0.1)
        gain2.gain.linearRampToValueAtTime(0.2, this.audioContext.currentTime + 0.15)
        gain2.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.4)
        
        osc1.start()
        osc2.start()
        osc1.stop(this.audioContext.currentTime + 0.3)
        osc2.stop(this.audioContext.currentTime + 0.4)
        break
      }
      
      case 'lap_complete': {
        // Victory fanfare
        const notes = [523.25, 659.25, 783.99, 1046.5] // C5, E5, G5, C6
        
        notes.forEach((note, index) => {
          setTimeout(() => {
            const osc = this.audioContext!.createOscillator()
            const gain = this.audioContext!.createGain()
            
            osc.connect(gain)
            gain.connect(this.effectsGain!)
            
            osc.frequency.setValueAtTime(note, this.audioContext!.currentTime)
            osc.type = 'triangle'
            
            gain.gain.setValueAtTime(0, this.audioContext!.currentTime)
            gain.gain.linearRampToValueAtTime(0.3, this.audioContext!.currentTime + 0.05)
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext!.currentTime + 0.4)
            
            osc.start()
            osc.stop(this.audioContext!.currentTime + 0.4)
          }, index * 100)
        })
        break
      }
      
      case 'race_start': {
        // Starting signal
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(440, this.audioContext.currentTime)
        osc.type = 'square'
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.4, this.audioContext.currentTime + 0.1)
        gain.gain.linearRampToValueAtTime(0.4, this.audioContext.currentTime + 0.8)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 1)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 1)
        break
      }
      
      case 'race_go': {
        // GO signal
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(880, this.audioContext.currentTime)
        osc.type = 'square'
        
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.5, this.audioContext.currentTime + 0.05)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3)
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.3)
        break
      }
      
      case 'race_finish': {
        // Finish line fanfare
        const melody = [523.25, 659.25, 783.99, 1046.5, 1318.5] // C5, E5, G5, C6, E6
        
        melody.forEach((note, index) => {
          setTimeout(() => {
            const osc = this.audioContext!.createOscillator()
            const gain = this.audioContext!.createGain()
            
            osc.connect(gain)
            gain.connect(this.effectsGain!)
            
            osc.frequency.setValueAtTime(note, this.audioContext!.currentTime)
            osc.type = 'sine'
            
            gain.gain.setValueAtTime(0, this.audioContext!.currentTime)
            gain.gain.linearRampToValueAtTime(0.4, this.audioContext!.currentTime + 0.05)
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext!.currentTime + 0.5)
            
            osc.start()
            osc.stop(this.audioContext!.currentTime + 0.5)
          }, index * 150)
        })
        break
      }
      
      default: {
        const osc = this.audioContext.createOscillator()
        const gain = this.audioContext.createGain()
        
        osc.connect(gain)
        gain.connect(this.effectsGain)
        
        osc.frequency.setValueAtTime(440, this.audioContext.currentTime)
        gain.gain.setValueAtTime(0, this.audioContext.currentTime)
        gain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.1)
        osc.type = 'sine'
        
        osc.start()
        osc.stop(this.audioContext.currentTime + 0.1)
      }
    }
  }

  cleanup() {
    this.stopBackgroundMusic()
    this.stopAnalysis()
    
    if (this.lfo) {
      try {
        this.lfo.stop()
      } catch (e) {
        // Might already be stopped
      }
    }
  }
}

// Audio Visualizer Component
const AudioVisualizer = ({ audioSystem }: { audioSystem: AudioSystem | null }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [levels, setLevels] = useState({ bass: 0, mid: 0, treble: 0, beat: false })
  
  useEffect(() => {
    if (!audioSystem) return
    
    const updateLevels = () => {
      const newLevels = audioSystem.getAudioLevels()
      setLevels(newLevels)
      requestAnimationFrame(updateLevels)
    }
    
    const frameId = requestAnimationFrame(updateLevels)
    
    return () => {
      cancelAnimationFrame(frameId)
    }
  }, [audioSystem])
  
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    
    // Draw bass level
    ctx.fillStyle = levels.beat ? '#ec4899' : '#a855f7'
    ctx.fillRect(0, 0, canvas.width * 0.3, canvas.height * (1 - levels.bass))
    ctx.fillRect(0, canvas.height * (1 - levels.bass), canvas.width * 0.3, canvas.height * levels.bass)
    
    // Draw mid level
    ctx.fillStyle = '#22d3ee'
    ctx.fillRect(canvas.width * 0.35, 0, canvas.width * 0.3, canvas.height * (1 - levels.mid))
    ctx.fillRect(canvas.width * 0.35, canvas.height * (1 - levels.mid), canvas.width * 0.3, canvas.height * levels.mid)
    
    // Draw treble level
    ctx.fillStyle = '#4ade80'
    ctx.fillRect(canvas.width * 0.7, 0, canvas.width * 0.3, canvas.height * (1 - levels.treble))
    ctx.fillRect(canvas.width * 0.7, canvas.height * (1 - levels.treble), canvas.width * 0.3, canvas.height * levels.treble)
    
  }, [levels])
  
  return (
    <div className={`w-full h-16 bg-black/50 rounded-lg overflow-hidden ${levels.beat ? 'border-2 border-pink-500' : 'border border-gray-700'}`}>
      <canvas 
        ref={canvasRef} 
        width={300} 
        height={60} 
        className="w-full h-full"
      />
    </div>
  )
}

// Racing Game Components
const RacingVehicleSelector = ({ vehicles, selectedVehicle, onSelect }: {
  vehicles: typeof RACING_VEHICLES
  selectedVehicle: typeof RACING_VEHICLES[0] | null
  onSelect: (vehicle: typeof RACING_VEHICLES[0]) => void
}) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {vehicles.map((vehicle) => (
        <Card 
          key={vehicle.id}
          className={`p-4 cursor-pointer transition-all hover:scale-105 ${
            selectedVehicle?.id === vehicle.id 
              ? 'border-2 border-green-500 bg-green-500/20' 
              : 'border border-gray-600 hover:border-green-500'
          }`}
          onClick={() => onSelect(vehicle)}
        >
          <div className="text-center">
            <div className="text-4xl mb-2">{vehicle.emoji}</div>
            <h3 className="text-sm font-bold text-white mb-2">{vehicle.name}</h3>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">Speed:</span>
                <div className="flex">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-2 h-2 mr-1 ${i < vehicle.speed ? 'bg-red-500' : 'bg-gray-600'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Accel:</span>
                <div className="flex">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-2 h-2 mr-1 ${i < vehicle.acceleration ? 'bg-yellow-500' : 'bg-gray-600'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Handle:</span>
                <div className="flex">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-2 h-2 mr-1 ${i < vehicle.handling ? 'bg-blue-500' : 'bg-gray-600'}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

const RacingTrackSelector = ({ tracks, selectedTrack, onSelect }: {
  tracks: typeof RACING_TRACKS
  selectedTrack: typeof RACING_TRACKS[0] | null
  onSelect: (track: typeof RACING_TRACKS[0]) => void
}) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400'
      case 'Medium': return 'text-yellow-400'
      case 'Hard': return 'text-orange-400'
      case 'Extreme': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {tracks.map((track) => (
        <Card 
          key={track.id}
          className={`p-4 cursor-pointer transition-all hover:scale-105 ${
            selectedTrack?.id === track.id 
              ? 'border-2 border-purple-500 bg-purple-500/20' 
              : 'border border-gray-600 hover:border-purple-500'
          }`}
          onClick={() => onSelect(track)}
        >
          <div className="text-center">
            <div className="text-4xl mb-2">{track.emoji}</div>
            <h3 className="text-sm font-bold text-white mb-2">{track.name}</h3>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">Difficulty:</span>
                <span className={getDifficultyColor(track.difficulty)}>{track.difficulty}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Laps:</span>
                <span className="text-white">{track.laps}</span>
              </div>
              <div className="flex justify-center gap-1 mt-2">
                {track.obstacles.map((obstacle, i) => (
                  <span key={i} className="text-lg">{obstacle}</span>
                ))}
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

const RacingLeaderboard = ({ scores }: { scores: Array<{name: string, time: number, vehicle: string, track: string}> }) => {
  const sortedScores = [...scores].sort((a, b) => a.time - b.time)

  return (
    <Card className="p-6 bg-black/80 backdrop-blur-sm border-2 border-yellow-500/50">
      <div className="flex items-center justify-center gap-2 mb-4">
        <Trophy className="w-6 h-6 text-yellow-400" />
        <h3 className="text-xl font-bold text-yellow-400">🏆 Leaderboard</h3>
      </div>
      
      {sortedScores.length === 0 ? (
        <p className="text-center text-gray-400">No races completed yet!</p>
      ) : (
        <div className="space-y-2">
          {sortedScores.slice(0, 10).map((score, index) => (
            <div 
              key={index}
              className={`flex items-center justify-between p-2 rounded ${
                index === 0 ? 'bg-yellow-500/20 border border-yellow-500/50' :
                index === 1 ? 'bg-gray-400/20 border border-gray-400/50' :
                index === 2 ? 'bg-orange-500/20 border border-orange-500/50' :
                'bg-gray-800/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`text-lg font-bold ${
                  index === 0 ? 'text-yellow-400' :
                  index === 1 ? 'text-gray-400' :
                  index === 2 ? 'text-orange-400' :
                  'text-white'
                }`}>
                  #{index + 1}
                </span>
                <div>
                  <div className="text-white font-medium">{score.name}</div>
                  <div className="text-xs text-gray-400">{score.vehicle} • {score.track}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white font-bold">{score.time.toFixed(2)}s</div>
                {index < 3 && (
                  <div className="text-xs">
                    {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}

// Enhanced Particle effect component
const Particle = ({ color, delay, mode }: { color: string; delay: number; mode: string }) => {
  const getAnimation = () => {
    switch (mode) {
      case 'Disco':
        return 'animate-spin'
      case 'Portal':
        return 'animate-pulse'
      case 'Fireworks':
        return 'animate-bounce'
      case 'Audio Reactive':
        return 'animate-ping'
      case 'Racing Mode':
        return 'animate-pulse'
      default:
        return 'animate-ping'
    }
  }

  return (
    <div 
      className={`absolute w-2 h-2 ${color} rounded-full ${getAnimation()}`}
      style={{
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        animationDelay: `${delay}s`,
        animationDuration: `${1 + Math.random() * 2}s`
      }}
    />
  )
}

// Constellation Emoji Component
const ConstellationEmoji = ({ emoji, position, index }: { emoji: string; position: { x: number; y: number }; index: number }) => {
  return (
    <div 
      className="absolute text-2xl opacity-60 animate-pulse"
      style={{
        left: `${position.x}%`,
        top: `${position.y}%`,
        animationDelay: `${index * 0.2}s`,
        filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.8))'
      }}
    >
      {emoji}
      <div 
        className="absolute w-px h-8 bg-white/30 origin-bottom"
        style={{
          transform: `rotate(${Math.random() * 360}deg)`,
          left: '50%',
          top: '50%'
        }}
      />
    </div>
  )
}

// Portal Effect Component
const PortalEffect = () => {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={i}
          className="absolute border-2 border-purple-500/30 rounded-full animate-ping"
          style={{
            left: '50%',
            top: '50%',
            width: `${(i + 1) * 100}px`,
            height: `${(i + 1) * 100}px`,
            transform: 'translate(-50%, -50%)',
            animationDelay: `${i * 0.5}s`,
            animationDuration: '3s'
          }}
        />
      ))}
    </div>
  )
}

// Interactive Side Emoji Component
const SideEmoji = ({ emoji, position, audioSystem, soundEnabled, audioReactive }: { 
  emoji: string; 
  position: { x: number; y: number }; 
  audioSystem: AudioSystem | null;
  soundEnabled: boolean;
  audioReactive: boolean;
}) => {
  const [clicked, setClicked] = useState(false)
  const [audioLevel, setAudioLevel] = useState(1)
  
  useEffect(() => {
    if (audioReactive && audioSystem) {
      const interval = setInterval(() => {
        const levels = audioSystem.getAudioLevels()
        setAudioLevel(1 + levels.bass * 2)
      }, 100)
      
      return () => clearInterval(interval)
    }
  }, [audioReactive, audioSystem])

  const handleClick = () => {
    if (soundEnabled && audioSystem) {
      audioSystem.playSound('emoji')
    }
    setClicked(true)
    setTimeout(() => setClicked(false), 500)
  }

  return (
    <div 
      className={`fixed text-3xl cursor-pointer transition-all duration-300 hover:scale-150 hover:rotate-12 z-20 ${
        clicked ? 'animate-bounce scale-150 rotate-45' : 'animate-pulse'
      }`}
      style={{
        left: `${position.x}%`,
        top: `${position.y}%`,
        filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.5))',
        textShadow: '0 0 20px rgba(255,255,255,0.8)',
        transform: audioReactive ? `scale(${audioLevel})` : undefined
      }}
      onClick={handleClick}
    >
      {emoji}
    </div>
  )
}

// Floating emoji component with enhanced effects
const FloatingEmoji = ({ emoji, delay, mode, audioReactive, bassLevel }: { 
  emoji: string; 
  delay: number; 
  mode: string;
  audioReactive: boolean;
  bassLevel: number;
}) => {
  const getAnimation = () => {
    switch (mode) {
      case 'Disco':
        return 'animate-spin'
      case 'DNA Spiral':
        return 'animate-bounce'
      case 'Weather Storm':
        return 'animate-pulse'
      case 'Audio Reactive':
        return ''
      case 'Racing Mode':
        return 'animate-bounce'
      default:
        return 'animate-bounce'
    }
  }

  return (
    <div 
      className={`absolute text-3xl opacity-30 pointer-events-none ${getAnimation()} transition-all duration-1000`}
      style={{
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        animationDelay: `${delay}s`,
        animationDuration: `${3 + Math.random() * 4}s`,
        filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.3))',
        transform: audioReactive ? `scale(${1 + bassLevel * 2}) rotate(${bassLevel * 360}deg)` : undefined
      }}
    >
      {emoji}
    </div>
  )
}

export default function RandomExpressionFilter() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const racingCanvasRef = useRef<HTMLCanvasElement>(null)
  const audioSystemRef = useRef<AudioSystem | null>(null)
  const racingGameRef = useRef<RacingGame | null>(null)
  
  const [isActive, setIsActive] = useState(false)
  const [currentEmoji, setCurrentEmoji] = useState('🤡')
  const [detectedExpression, setDetectedExpression] = useState('neutral')
  const [message, setMessage] = useState('')
  const [personDetected, setPersonDetected] = useState(false)
  const [emojiFixed, setEmojiFixed] = useState(false)
  const [selectedFrame, setSelectedFrame] = useState(0)
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([])
  const [showPhotos, setShowPhotos] = useState(false)
  const [uselessFact, setUselessFact] = useState('')
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [musicEnabled, setMusicEnabled] = useState(false)
  const [musicStyle, setMusicStyle] = useState(0)
  const [musicVolume, setMusicVolume] = useState(0.5)
  const [effectsVolume, setEffectsVolume] = useState(0.5)
  const [showMusicControls, setShowMusicControls] = useState(false)
  const [currentSound, setCurrentSound] = useState('')
  const [currentTheme, setCurrentTheme] = useState(0)
  const [specialMode, setSpecialMode] = useState(0)
  const [aiAnalysis, setAiAnalysis] = useState({
    confusion: 0,
    absurdity: 0,
    mismatchPower: 0,
    cosmicEnergy: 0
  })
  const [totalWastedTime, setTotalWastedTime] = useState(0)
  const [floatingEmojis, setFloatingEmojis] = useState<string[]>([])
  const [sideEmojis, setSideEmojis] = useState<Array<{emoji: string, position: {x: number, y: number}}>>([])
  const [constellationEmojis, setConstellationEmojis] = useState<Array<{emoji: string, position: {x: number, y: number}}>>([])
  const [particles, setParticles] = useState<string[]>([])
  const [emojiRain, setEmojiRain] = useState(false)
  const [glitchEffect, setGlitchEffect] = useState(false)
  const [audioInitialized, setAudioInitialized] = useState(false)
  const [discoMode, setDiscoMode] = useState(false)
  const [multiEmoji, setMultiEmoji] = useState(false)
  const [audioLevels, setAudioLevels] = useState({ bass: 0, mid: 0, treble: 0, beat: false })
  const [beatDetected, setBeatDetected] = useState(false)

  // Racing game states
  const [isRacingMode, setIsRacingMode] = useState(false)
  const [selectedVehicle, setSelectedVehicle] = useState<typeof RACING_VEHICLES[0] | null>(null)
  const [selectedTrack, setSelectedTrack] = useState<typeof RACING_TRACKS[0] | null>(null)
  const [raceState, setRaceState] = useState<'menu' | 'vehicle_select' | 'track_select' | 'racing' | 'finished'>('menu')
  const [raceResults, setRaceResults] = useState<{time: number, position: number} | null>(null)
  const [leaderboard, setLeaderboard] = useState<Array<{name: string, time: number, vehicle: string, track: string}>>([])
  const [playerName, setPlayerName] = useState('Player')
  const [showLeaderboard, setShowLeaderboard] = useState(false)

  // Initialize audio system
  useEffect(() => {
    audioSystemRef.current = new AudioSystem()
    
    // Set beat detection callback
    audioSystemRef.current.setOnBeatCallback(() => {
      setBeatDetected(true)
      setTimeout(() => setBeatDetected(false), 100)
    })
    
    // Update audio levels
    const updateAudioLevels = () => {
      if (audioSystemRef.current) {
        setAudioLevels(audioSystemRef.current.getAudioLevels())
      }
      requestAnimationFrame(updateAudioLevels)
    }
    
    const frameId = requestAnimationFrame(updateAudioLevels)
    
    return () => {
      cancelAnimationFrame(frameId)
      if (audioSystemRef.current) {
        audioSystemRef.current.cleanup()
      }
      if (racingGameRef.current) {
        racingGameRef.current.cleanup()
      }
    }
  }, [])

  // Initialize racing game when canvas is available
  useEffect(() => {
    if (racingCanvasRef.current && !racingGameRef.current) {
      racingGameRef.current = new RacingGame(racingCanvasRef.current, audioSystemRef.current)
      
      racingGameRef.current.setRaceCompleteCallback((time: number, position: number) => {
        setRaceResults({ time, position })
        setRaceState('finished')
        
        // Add to leaderboard
        if (selectedVehicle && selectedTrack) {
          const newScore = {
            name: playerName,
            time,
            vehicle: selectedVehicle.name,
            track: selectedTrack.name
          }
          setLeaderboard(prev => [...prev, newScore])
        }
      })
    }
  }, [isRacingMode, playerName, selectedVehicle, selectedTrack])

  // Initialize audio context on first user interaction
  const initializeAudio = async () => {
    if (!audioInitialized && audioSystemRef.current) {
      try {
        await audioSystemRef.current.playSound('click')
        setAudioInitialized(true)
      } catch (error) {
        console.log('Audio initialization failed:', error)
      }
    }
  }

  // Generate random floating emojis, side emojis, and particles
  useEffect(() => {
    const emojis = Array.from({ length: 30 }, () => 
      FLOATING_EMOJIS[Math.floor(Math.random() * FLOATING_EMOJIS.length)]
    )
    setFloatingEmojis(emojis)
    
    // Generate constellation pattern
    const constellation = Array.from({ length: 12 }, (_, i) => ({
      emoji: '⭐',
      position: {
        x: 20 + (i % 4) * 20,
        y: 20 + Math.floor(i / 4) * 20
      }
    }))
    setConstellationEmojis(constellation)
    
    // Generate side emojis with random positions
    const sideEmojiData = Array.from({ length: 20 }, () => ({
      emoji: SIDE_EMOJIS[Math.floor(Math.random() * SIDE_EMOJIS.length)],
      position: {
        x: Math.random() < 0.5 ? Math.random() * 15 : 85 + Math.random() * 15,
        y: Math.random() * 80 + 10
      }
    }))
    setSideEmojis(sideEmojiData)
    
    const particleColors = ['bg-pink-400', 'bg-cyan-400', 'bg-purple-400', 'bg-green-400', 'bg-yellow-400', 'bg-orange-400', 'bg-red-400', 'bg-blue-400']
    setParticles(Array.from({ length: 50 }, () => 
      particleColors[Math.floor(Math.random() * particleColors.length)]
    ))
  }, [])

  // Background music control
  const toggleMusic = async () => {
    if (!audioSystemRef.current) return
    
    await initializeAudio()
    
    if (musicEnabled) {
      audioSystemRef.current.stopBackgroundMusic()
      setMusicEnabled(false)
    } else {
      audioSystemRef.current.setMusicStyle(MUSIC_STYLES[musicStyle])
      await audioSystemRef.current.startBackgroundMusic()
      setMusicEnabled(true)
    }
  }

  // Update music style
  useEffect(() => {
    if (musicEnabled && audioSystemRef.current) {
      audioSystemRef.current.setMusicStyle(MUSIC_STYLES[musicStyle])
      audioSystemRef.current.stopBackgroundMusic()
      audioSystemRef.current.startBackgroundMusic()
    }
  }, [musicStyle, musicEnabled])

  // Update music volume
  useEffect(() => {
    if (audioSystemRef.current) {
      audioSystemRef.current.setMusicVolume(musicVolume)
    }
  }, [musicVolume])

  // Update effects volume
  useEffect(() => {
    if (audioSystemRef.current) {
      audioSystemRef.current.setEffectsVolume(effectsVolume)
    }
  }, [effectsVolume])

  // Racing mode effects
  useEffect(() => {
    if (specialMode === 8) { // Racing Mode
      setIsRacingMode(true)
      if (musicStyle !== 6) { // Switch to Racing music
        setMusicStyle(6)
      }
    } else {
      setIsRacingMode(false)
      setRaceState('menu')
    }
  }, [specialMode])

  // Disco mode effect
  useEffect(() => {
    if (specialMode === 1) { // Disco mode
      const interval = setInterval(() => {
        setDiscoMode(prev => !prev)
      }, 500)
      return () => clearInterval(interval)
    }
  }, [specialMode])

  // Play sound effect
  const playSound = async (soundType: string) => {
    if (soundEnabled && audioSystemRef.current) {
      await initializeAudio()
      await audioSystemRef.current.playSound(soundType)
      
      // Show visual sound effect
      const soundIndex = Math.floor(Math.random() * SOUND_EFFECTS.length)
      setCurrentSound(SOUND_EFFECTS[soundIndex])
      setTimeout(() => setCurrentSound(''), 2000)
    }
  }

  // Useless time waster counter
  useEffect(() => {
    const interval = setInterval(() => {
      setTotalWastedTime(prev => prev + 0.1)
    }, 100)
    return () => clearInterval(interval)
  }, [])

  // Generate useless AI analysis
  const generateUselessAnalysis = useCallback(() => {
    setAiAnalysis({
      confusion: Math.floor(Math.random() * 100) + 1,
      absurdity: Math.floor(Math.random() * 100) + 1,
      mismatchPower: Math.floor(Math.random() * 9000) + 1000,
      cosmicEnergy: Math.floor(Math.random() * 100) + 1
    })
  }, [])

  // Trigger glitch effect
  const triggerGlitch = () => {
    setGlitchEffect(true)
    setTimeout(() => setGlitchEffect(false), 500)
  }

  // Racing game functions
  const startVehicleSelection = () => {
    setRaceState('vehicle_select')
    playSound('click')
  }

  const selectVehicle = (vehicle: typeof RACING_VEHICLES[0]) => {
    setSelectedVehicle(vehicle)
    if (racingGameRef.current) {
      racingGameRef.current.setVehicle(vehicle)
    }
    setRaceState('track_select')
    playSound('engine')
  }

  const selectTrack = (track: typeof RACING_TRACKS[0]) => {
    setSelectedTrack(track)
    if (racingGameRef.current) {
      racingGameRef.current.setTrack(track)
    }
    playSound('click')
  }

  const startRace = () => {
    if (racingGameRef.current && selectedVehicle && selectedTrack) {
      setRaceState('racing')
      racingGameRef.current.startRace()
      playSound('race_start')
    }
  }

  const resetRace = () => {
    setRaceState('menu')
    setRaceResults(null)
    setSelectedVehicle(null)
    setSelectedTrack(null)
    playSound('reset')
  }

  // Simulated face detection and expression analysis
  const analyzeExpression = useCallback(() => {
    const expressions = Object.keys(EXPRESSION_EMOJIS)
    const randomExpression = expressions[Math.floor(Math.random() * expressions.length)]
    setDetectedExpression(randomExpression)
    
    // Simulate person detection
    const isPersonPresent = Math.random() > 0.2
    setPersonDetected(isPersonPresent)
    
    if (isPersonPresent && !emojiFixed) {
      const mismatchedEmoji = getMismatchedEmoji(randomExpression)
      setCurrentEmoji(mismatchedEmoji)
      setEmojiFixed(true)
      
      const detectedEmoji = EXPRESSION_EMOJIS[randomExpression as keyof typeof EXPRESSION_EMOJIS][0]
      setMessage(`Your face says ${detectedEmoji}, but the algorithm says ${mismatchedEmoji}`)
      
      // Generate useless fact
      setUselessFact(USELESS_FACTS[Math.floor(Math.random() * USELESS_FACTS.length)])
      
      // Update AI analysis
      generateUselessAnalysis()
      
      // Play sound
      playSound('mismatch')
      
      // Trigger glitch effect
      triggerGlitch()
    } else if (!isPersonPresent) {
      setEmojiFixed(false)
      setMessage('🔍 Scanning for facial incompatibility... Prepare for chaos!')
    }
  }, [emojiFixed, generateUselessAnalysis])

  const getMismatchedEmoji = (detectedExpression: string) => {
    const matchingEmojis = EXPRESSION_EMOJIS[detectedExpression as keyof typeof EXPRESSION_EMOJIS] || []
    const availableEmojis = ALL_EMOJIS.filter(emoji => !matchingEmojis.includes(emoji))
    return availableEmojis[Math.floor(Math.random() * availableEmojis.length)]
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        } 
      })
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
        setIsActive(true)
        setEmojiFixed(false)
        await playSound('camera')
      }
    } catch (error) {
      console.error('Error accessing camera:', error)
      alert('Unable to access camera. Please ensure you have granted camera permissions.')
    }
  }

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach(track => track.stop())
      videoRef.current.srcObject = null
    }
    setIsActive(false)
    setMessage('')
    setPersonDetected(false)
    setEmojiFixed(false)
    playSound('click')
  }

  const resetEmoji = () => {
    setEmojiFixed(false)
    setMessage('🔄 Recalibrating mismatch algorithms... Maximum chaos incoming!')
    generateUselessAnalysis()
    playSound('reset')
    triggerGlitch()
  }

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')

    if (!ctx) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    ctx.save()
    ctx.scale(-1, 1)
    ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height)
    ctx.restore()

    const frame = CREATIVE_FRAMES[selectedFrame]
    if (frame.name !== 'None') {
      ctx.strokeStyle = getFrameColor(frame.name)
      ctx.lineWidth = 20
      ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20)
    }

    if (personDetected && currentEmoji) {
      ctx.font = `${Math.min(canvas.width, canvas.height) * 0.2}px Arial`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      
      ctx.shadowColor = 'rgba(0, 0, 0, 0.8)'
      ctx.shadowBlur = 15
      ctx.shadowOffsetX = 3
      ctx.shadowOffsetY = 3
      
      ctx.fillText(currentEmoji, canvas.width / 2, canvas.height / 2)

      // Multi-emoji mode
      if (multiEmoji) {
        ctx.font = `${Math.min(canvas.width, canvas.height) * 0.1}px Arial`
        const extraEmojis = [
          ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)],
          ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)],
          ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)]
        ]
        ctx.fillText(extraEmojis[0], canvas.width / 4, canvas.height / 4)
        ctx.fillText(extraEmojis[1], (canvas.width * 3) / 4, canvas.height / 4)
        ctx.fillText(extraEmojis[2], canvas.width / 2, (canvas.height * 3) / 4)
      }
    }

    ctx.shadowColor = 'transparent'
    ctx.font = '24px Arial'
    ctx.fillStyle = '#00ffff'
    ctx.strokeStyle = '#000000'
    ctx.lineWidth = 2
    ctx.textAlign = 'left'
    
    const timestamp = new Date().toLocaleString()
    ctx.strokeText(`🎭 Epic Mismatch - Power Level: ${aiAnalysis.mismatchPower} - ${timestamp}`, 20, canvas.height - 30)
    ctx.fillText(`🎭 Epic Mismatch - Power Level: ${aiAnalysis.mismatchPower} - ${timestamp}`, 20, canvas.height - 30)

    const dataURL = canvas.toDataURL('image/png')
    setCapturedPhotos(prev => [dataURL, ...prev])
    
    const link = document.createElement('a')
    link.download = `epic-mismatch-${Date.now()}.png`
    link.href = dataURL
    link.click()
    
    // Trigger emoji rain effect
    setEmojiRain(true)
    setTimeout(() => setEmojiRain(false), 3000)
    
    playSound('capture')
  }

  const getFrameColor = (frameName: string) => {
    switch (frameName) {
      case 'Neon Pink': return '#ec4899'
      case 'Cyber Blue': return '#22d3ee'
      case 'Electric Purple': return '#a855f7'
      case 'Toxic Green': return '#4ade80'
      case 'Fire Orange': return '#f97316'
      case 'Galaxy': return '#6366f1'
      case 'Holographic': return '#ec4899'
      case 'Sound Wave': return '#22d3ee'
      default: return '#ffffff'
    }
  }

  const generateRandomFloatingEmojis = () => {
    const newEmojis = Array.from({ length: 30 }, () => 
      FLOATING_EMOJIS[Math.floor(Math.random() * FLOATING_EMOJIS.length)]
    )
    setFloatingEmojis(newEmojis)
    
    // Also regenerate side emojis
    const newSideEmojis = Array.from({ length: 20 }, () => ({
      emoji: SIDE_EMOJIS[Math.floor(Math.random() * SIDE_EMOJIS.length)],
      position: {
        x: Math.random() < 0.5 ? Math.random() * 15 : 85 + Math.random() * 15,
        y: Math.random() * 80 + 10
      }
    }))
    setSideEmojis(newSideEmojis)
    
    playSound('reset')
  }

  useEffect(() => {
    if (isActive && !isRacingMode) {
      const interval = setInterval(analyzeExpression, 1500)
      return () => clearInterval(interval)
    }
  }, [isActive, analyzeExpression, isRacingMode])

  // Regenerate floating emojis periodically
  useEffect(() => {
    const interval = setInterval(generateRandomFloatingEmojis, 8000)
    return () => clearInterval(interval)
  }, [])

  const currentColorTheme = COLOR_THEMES[currentTheme]
  const currentSpecialMode = SPECIAL_MODES[specialMode]
  const isAudioReactive = specialMode === 7

  return (
    <div className={`min-h-screen bg-gradient-to-br ${currentColorTheme.bg} p-4 relative overflow-hidden ${discoMode ? 'animate-pulse' : ''} ${beatDetected ? 'scale-[1.01] transition-transform duration-75' : ''}`}>
      {/* Animated Background Particles */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {particles.map((color, index) => (
          <Particle key={`particle-${index}`} color={color} delay={index * 0.1} mode={currentSpecialMode} />
        ))}
      </div>

      {/* Special Mode Effects */}
      {currentSpecialMode === 'Constellation' && (
        <div className="fixed inset-0 pointer-events-none z-0">
          {constellationEmojis.map((item, index) => (
            <ConstellationEmoji key={`constellation-${index}`} emoji={item.emoji} position={item.position} index={index} />
          ))}
        </div>
      )}

      {currentSpecialMode === 'Portal' && (
        <div className="fixed inset-0 pointer-events-none z-0">
          <PortalEffect />
        </div>
      )}

      {/* Floating Background Emojis */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {floatingEmojis.map((emoji, index) => (
          <FloatingEmoji 
            key={`${emoji}-${index}`} 
            emoji={emoji} 
            delay={index * 0.2} 
            mode={currentSpecialMode}
            audioReactive={isAudioReactive}
            bassLevel={audioLevels.bass}
          />
        ))}
      </div>

      {/* Interactive Side Emojis */}
      {!isRacingMode && sideEmojis.map((item, index) => (
        <SideEmoji 
          key={`side-${index}`} 
          emoji={item.emoji} 
          position={item.position}
          audioSystem={audioSystemRef.current}
          soundEnabled={soundEnabled}
          audioReactive={isAudioReactive}
        />
      ))}

      {/* Emoji Rain Effect */}
      {emojiRain && (
        <div className="fixed inset-0 pointer-events-none z-20">
          {Array.from({ length: 100 }).map((_, i) => (
            <div
              key={i}
              className="absolute text-4xl animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `-10%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: '3s'
              }}
            >
              {ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)]}
            </div>
          ))}
        </div>
      )}

      {/* Glitch Effect Overlay */}
      {glitchEffect && (
        <div className="fixed inset-0 bg-gradient-to-r from-red-500/20 via-transparent to-blue-500/20 z-10 animate-pulse pointer-events-none" />
      )}

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className={`text-4xl md:text-7xl font-bold bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-4 ${beatDetected ? 'scale-110' : 'animate-pulse'} transition-transform`}>
            🎭 THE RANDOM-EXPRESSION FILTER {isRacingMode ? '🏎️' : '🎪'}
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto mb-4">
            {isRacingMode 
              ? "The world's most chaotic racing experience with emoji-powered vehicles! Race through absurd tracks while your face gets hilariously mismatched!"
              : "The world's most advanced facial-emoji mismatch technology with epic background music! Scientifically designed to be 100% wrong, 100% of the time."
            }
          </p>
          <div className="flex justify-center gap-4 text-sm text-gray-400 flex-wrap">
            <span className="bg-gray-800/50 px-3 py-1 rounded-full border border-purple-500/30">⏰ Time Wasted: {totalWastedTime.toFixed(1)}s</span>
            <span className="bg-gray-800/50 px-3 py-1 rounded-full border border-pink-500/30">🎯 Accuracy: 0.00%</span>
            <span className="bg-gray-800/50 px-3 py-1 rounded-full border border-cyan-500/30">🏆 Uselessness: MAXIMUM</span>
            <span className={`bg-gray-800/50 px-3 py-1 rounded-full border ${musicEnabled ? 'border-green-500/50 text-green-400' : 'border-gray-500/30'}`}>
              🎵 Music: {musicEnabled ? MUSIC_STYLES[musicStyle] : 'OFF'}
            </span>
            {isRacingMode && (
              <span className="bg-gray-800/50 px-3 py-1 rounded-full border border-orange-500/30 text-orange-400">
                🏎️ Racing Mode Active
              </span>
            )}
          </div>
        </div>

        {/* Sound Effect Display */}
        {currentSound && (
          <div className="fixed top-4 right-4 z-30 bg-black/80 text-cyan-400 px-4 py-2 rounded-lg border border-cyan-500/50 animate-bounce">
            <Music className="w-4 h-4 inline mr-2" />
            {currentSound}
          </div>
        )}

        {/* Control Panel */}
        <div className="fixed top-4 left-4 z-30 flex flex-col gap-2">
          <Button
            onClick={async () => {
              setSoundEnabled(!soundEnabled)
              await playSound('click')
            }}
            variant="outline"
            size="sm"
            className="bg-black/50 border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>
          
          <Button
            onClick={toggleMusic}
            variant="outline"
            size="sm"
            className={`bg-black/50 border-green-500/50 text-green-400 hover:bg-green-500/20 ${musicEnabled ? 'bg-green-500/20' : ''}`}
          >
            <Music className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={() => setShowMusicControls(!showMusicControls)}
            variant="outline"
            size="sm"
            className={`bg-black/50 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20 ${showMusicControls ? 'bg-cyan-500/20' : ''}`}
          >
            <Radio className="w-4 h-4" />
          </Button>

          {isRacingMode && (
            <Button
              onClick={() => setShowLeaderboard(!showLeaderboard)}
              variant="outline"
              size="sm"
              className={`bg-black/50 border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20 ${showLeaderboard ? 'bg-yellow-500/20' : ''}`}
            >
              <Trophy className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Music Controls Panel */}
        {showMusicControls && (
          <div className="fixed top-4 left-16 z-30 bg-black/80 p-4 rounded-lg border border-cyan-500/50 backdrop-blur-sm w-64">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-cyan-400 text-sm font-bold flex items-center gap-1">
                <Headphones className="w-4 h-4" /> Audio Controls
              </h3>
              <Button
                onClick={() => setShowMusicControls(false)}
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              >
                ✕
              </Button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-300 mb-1 block">Music Style</label>
                <select 
                  value={musicStyle} 
                  onChange={(e) => {
                    setMusicStyle(Number(e.target.value))
                    playSound('theme')
                  }}
                  className="w-full bg-black/50 text-white text-xs rounded px-2 py-1 border border-gray-600"
                >
                  {MUSIC_STYLES.map((style, index) => (
                    <option key={index} value={index}>{style}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="text-xs text-gray-300 mb-1 flex justify-between">
                  <span>Music Volume</span>
                  <span>{Math.round(musicVolume * 100)}%</span>
                </label>
                <Slider
                  value={[musicVolume * 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(value) => setMusicVolume(value[0] / 100)}
                  className="my-2"
                />
              </div>
              
              <div>
                <label className="text-xs text-gray-300 mb-1 flex justify-between">
                  <span>Effects Volume</span>
                  <span>{Math.round(effectsVolume * 100)}%</span>
                </label>
                <Slider
                  value={[effectsVolume * 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(value) => setEffectsVolume(value[0] / 100)}
                  className="my-2"
                />
              </div>
              
              <AudioVisualizer audioSystem={audioSystemRef.current} />
              
              <div className="flex justify-between">
                <Button
                  onClick={toggleMusic}
                  variant="outline"
                  size="sm"
                  className={`bg-black/50 border-green-500/50 text-green-400 hover:bg-green-500/20 ${musicEnabled ? 'bg-green-500/20' : ''}`}
                >
                  {musicEnabled ? 'Stop Music' : 'Play Music'}
                </Button>
                
                <Button
                  onClick={() => {
                    if (audioSystemRef.current) {
                      audioSystemRef.current.playSound('theme')
                    }
                  }}
                  variant="outline"
                  size="sm"
                  className="bg-black/50 border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                >
                  Test Sound
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Leaderboard Panel */}
        {showLeaderboard && isRacingMode && (
          <div className="fixed top-4 right-4 z-30 w-80">
            <RacingLeaderboard scores={leaderboard} />
          </div>
        )}

        {/* Theme and Mode Selectors */}
        <div className="flex justify-center gap-4 mb-6 flex-wrap">
          <Card className="p-3 bg-black/70 backdrop-blur-sm border-2 border-purple-500/30">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-400">Theme:</span>
              <select 
                value={currentTheme} 
                onChange={(e) => {
                  setCurrentTheme(Number(e.target.value))
                  playSound('theme')
                }}
                className="bg-black/50 text-white text-xs rounded px-2 py-1 border border-gray-600"
              >
                {COLOR_THEMES.map((theme, index) => (
                  <option key={index} value={index}>{theme.name}</option>
                ))}
              </select>
            </div>
          </Card>

          <Card className="p-3 bg-black/70 backdrop-blur-sm border-2 border-pink-500/30">
            <div className="flex items-center gap-2">
              <Wand2 className="w-4 h-4 text-pink-400" />
              <span className="text-sm text-pink-400">Mode:</span>
              <select 
                value={specialMode} 
                onChange={(e) => {
                  setSpecialMode(Number(e.target.value))
                  playSound('theme')
                }}
                className="bg-black/50 text-white text-xs rounded px-2 py-1 border border-gray-600"
              >
                {SPECIAL_MODES.map((mode, index) => (
                  <option key={index} value={index}>{mode}</option>
                ))}
              </select>
            </div>
          </Card>

          {!isRacingMode && (
            <Button
              onClick={() => {
                setMultiEmoji(!multiEmoji)
                playSound('click')
              }}
              variant="outline"
              size="sm"
              className={`border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20 ${multiEmoji ? 'bg-yellow-500/20' : ''}`}
            >
              <Rocket className="w-4 h-4 mr-1" />
              Multi-Emoji
            </Button>
          )}

          {isRacingMode && (
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-300">Player Name:</label>
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="bg-black/50 text-white text-sm rounded px-2 py-1 border border-gray-600 w-24"
                maxLength={12}
              />
            </div>
          )}
        </div>

        {/* Audio Initialization Notice */}
        {!audioInitialized && (
          <div className="fixed bottom-4 left-4 z-30 bg-yellow-900/80 text-yellow-400 px-4 py-2 rounded-lg border border-yellow-500/50 text-sm">
            🔊 Click any button to enable sound effects and music!
          </div>
        )}

        {/* Main Content */}
        <div className="flex flex-col items-center space-y-6">
          {/* Racing Game Content */}
          {isRacingMode ? (
            <div className="w-full max-w-6xl">
              {raceState === 'menu' && (
                <Card className="p-8 bg-black/80 backdrop-blur-sm border-2 border-orange-500/50 text-center">
                  <div className="text-6xl mb-4">🏎️</div>
                  <h2 className="text-3xl font-bold text-orange-400 mb-4">CHAOS RACING</h2>
                  <p className="text-gray-300 mb-6">
                    Welcome to the most absurd racing experience ever created! 
                    Choose your emoji-powered vehicle and race through impossible tracks!
                  </p>
                  <Button
                    onClick={startVehicleSelection}
                    size="lg"
                    className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white px-8 py-3 text-lg"
                  >
                    <Car className="w-5 h-5 mr-2" />
                    START RACING
                  </Button>
                </Card>
              )}

              {raceState === 'vehicle_select' && (
                <Card className="p-6 bg-black/80 backdrop-blur-sm border-2 border-green-500/50">
                  <h2 className="text-2xl font-bold text-green-400 mb-4 text-center">
                    🚗 Choose Your Vehicle
                  </h2>
                  <RacingVehicleSelector
                    vehicles={RACING_VEHICLES}
                    selectedVehicle={selectedVehicle}
                    onSelect={selectVehicle}
                  />
                </Card>
              )}

              {raceState === 'track_select' && selectedVehicle && (
                <Card className="p-6 bg-black/80 backdrop-blur-sm border-2 border-purple-500/50">
                  <h2 className="text-2xl font-bold text-purple-400 mb-4 text-center">
                    🏁 Choose Your Track
                  </h2>
                  <RacingTrackSelector
                    tracks={RACING_TRACKS}
                    selectedTrack={selectedTrack}
                    onSelect={selectTrack}
                  />
                  {selectedTrack && (
                    <div className="mt-6 text-center">
                      <Button
                        onClick={startRace}
                        size="lg"
                        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg"
                      >
                        <Flag className="w-5 h-5 mr-2" />
                        START RACE
                      </Button>
                    </div>
                  )}
                </Card>
              )}

              {raceState === 'racing' && (
                <Card className="p-4 bg-black/80 backdrop-blur-sm border-2 border-red-500/50">
                  <div className="text-center mb-4">
                    <h2 className="text-xl font-bold text-red-400">
                      🏎️ {selectedTrack?.name} - {selectedVehicle?.name}
                    </h2>
                    <p className="text-sm text-gray-400">
                      Use WASD or Arrow Keys to control your vehicle
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <canvas
                      ref={racingCanvasRef}
                      width={800}
                      height={600}
                      className="border-2 border-gray-600 rounded-lg bg-gray-900"
                    />
                  </div>
                  <div className="mt-4 text-center">
                    <Button
                      onClick={() => {
                        if (racingGameRef.current) {
                          racingGameRef.current.pauseRace()
                        }
                        resetRace()
                      }}
                      variant="outline"
                      className="border-red-500/50 text-red-400 hover:bg-red-500/20"
                    >
                      Exit Race
                    </Button>
                  </div>
                </Card>
              )}

              {raceState === 'finished' && raceResults && (
                <Card className="p-8 bg-black/80 backdrop-blur-sm border-2 border-yellow-500/50 text-center">
                  <div className="text-6xl mb-4">
                    {raceResults.position === 1 ? '🏆' : raceResults.position <= 3 ? '🥉' : '🏁'}
                  </div>
                  <h2 className="text-3xl font-bold text-yellow-400 mb-4">
                    RACE COMPLETE!
                  </h2>
                  <div className="space-y-2 mb-6">
                    <p className="text-xl text-white">
                      Position: <span className="text-yellow-400">#{raceResults.position}</span>
                    </p>
                    <p className="text-xl text-white">
                      Time: <span className="text-green-400">{raceResults.time.toFixed(2)}s</span>
                    </p>
                    <p className="text-sm text-gray-400">
                      Vehicle: {selectedVehicle?.name} • Track: {selectedTrack?.name}
                    </p>
                  </div>
                  <div className="flex gap-4 justify-center">
                    <Button
                      onClick={startRace}
                      className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white"
                    >
                      Race Again
                    </Button>
                    <Button
                      onClick={resetRace}
                      variant="outline"
                      className="border-gray-500/50 text-gray-400 hover:bg-gray-500/20"
                    >
                      Back to Menu
                    </Button>
                  </div>
                </Card>
              )}
            </div>
          ) : (
            <>
              {/* Original Emoji Filter Content */}
              {/* Useless AI Analysis Dashboard */}
              {isActive && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <Card className={`p-4 bg-gradient-to-r from-purple-600/80 to-pink-600/80 text-white border border-purple-500/50 backdrop-blur-sm ${isAudioReactive ? 'scale-y-[' + (1 + audioLevels.bass) + ']' : ''} transition-transform`}>
                    <div className="flex items-center gap-2">
                      <Brain className="w-5 h-5 animate-pulse" />
                      <div>
                        <p className="text-xs opacity-80">Confusion Level</p>
                        <p className="text-xl font-bold">{aiAnalysis.confusion}%</p>
                      </div>
                    </div>
                  </Card>
                  <Card className={`p-4 bg-gradient-to-r from-blue-600/80 to-cyan-600/80 text-white border border-cyan-500/50 backdrop-blur-sm ${isAudioReactive ? 'scale-y-[' + (1 + audioLevels.mid) + ']' : ''} transition-transform`}>
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 animate-bounce" />
                      <div>
                        <p className="text-xs opacity-80">Absurdity Index</p>
                        <p className="text-xl font-bold">{aiAnalysis.absurdity}%</p>
                      </div>
                    </div>
                  </Card>
                  <Card className={`p-4 bg-gradient-to-r from-green-600/80 to-emerald-600/80 text-white border border-green-500/50 backdrop-blur-sm ${isAudioReactive ? 'scale-y-[' + (1 + audioLevels.treble) + ']' : ''} transition-transform`}>
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5 animate-spin" />
                      <div>
                        <p className="text-xs opacity-80">Mismatch Power</p>
                        <p className="text-xl font-bold">{aiAnalysis.mismatchPower}</p>
                      </div>
                    </div>
                  </Card>
                  <Card className={`p-4 bg-gradient-to-r from-orange-600/80 to-red-600/80 text-white border border-orange-500/50 backdrop-blur-sm ${audioLevels.beat ? 'scale-110' : ''} transition-transform`}>
                    <div className="flex items-center gap-2">
                      <Heart className="w-5 h-5 animate-pulse" />
                      <div>
                        <p className="text-xs opacity-80">Cosmic Energy</p>
                        <p className="text-xl font-bold">{aiAnalysis.cosmicEnergy}%</p>
                      </div>
                    </div>
                  </Card>
                </div>
              )}

              {/* Camera Feed */}
              <Card className={`relative overflow-hidden bg-black ${CREATIVE_FRAMES[selectedFrame].style} ${CREATIVE_FRAMES[selectedFrame].glow} transform hover:scale-105 transition-all duration-300 border-2 border-gray-700 ${beatDetected ? 'scale-105' : ''}`}>
                <div className="relative">
                  <video
                    ref={videoRef}
                    className={`w-full max-w-2xl h-auto ${glitchEffect ? 'animate-pulse filter hue-rotate-180' : ''}`}
                    autoPlay
                    muted
                    playsInline
                    style={{ transform: 'scaleX(-1)' }}
                  />
                  
                  {/* Audio Reactive Frame */}
                  {isAudioReactive && isActive && (
                    <div className="absolute inset-0 pointer-events-none">
                      <div 
                        className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500"
                        style={{ transform: `scaleX(${audioLevels.bass * 2})`, transformOrigin: 'center' }}
                      ></div>
                      <div 
                        className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500"
                        style={{ transform: `scaleX(${audioLevels.treble * 2})`, transformOrigin: 'center' }}
                      ></div>
                      <div 
                        className="absolute top-0 bottom-0 left-0 w-1 bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500"
                        style={{ transform: `scaleY(${audioLevels.mid * 2})`, transformOrigin: 'center' }}
                      ></div>
                      <div 
                        className="absolute top-0 bottom-0 right-0 w-1 bg-gradient-to-b from-pink-500 via-purple-500 to-cyan-500"
                        style={{ transform: `scaleY(${audioLevels.mid * 2})`, transformOrigin: 'center' }}
                      ></div>
                    </div>
                  )}
                  
                  {/* Emoji Overlay with enhanced effects */}
                  {isActive && personDetected && emojiFixed && (
                    <>
                      <div 
                        className={`absolute text-6xl md:text-8xl pointer-events-none cursor-pointer ${isAudioReactive ? '' : 'animate-bounce'}`}
                        style={{
                          left: '50%',
                          top: '50%',
                          transform: `translate(-50%, -50%) ${isAudioReactive ? `scale(${1 + audioLevels.bass * 2}) rotate(${audioLevels.mid * 45}deg)` : ''}`,
                          textShadow: '3px 3px 6px rgba(0,0,0,0.8)',
                          filter: 'drop-shadow(0 0 20px rgba(255,255,255,0.8)) hue-rotate(45deg)',
                          transition: 'transform 0.1s ease-out'
                        }}
                        onClick={() => playSound('emoji')}
                      >
                        {currentEmoji}
                      </div>
                      
                      {/* Multi-emoji mode */}
                      {multiEmoji && (
                        <>
                          <div 
                            className={`absolute text-3xl ${isAudioReactive ? '' : 'animate-spin'}`} 
                            style={{ 
                              left: '25%', 
                              top: '25%',
                              transform: isAudioReactive ? `scale(${1 + audioLevels.treble}) rotate(${audioLevels.treble * 360}deg)` : '',
                              transition: 'transform 0.1s ease-out'
                            }}
                          >
                            {ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)]}
                          </div>
                          <div 
                            className={`absolute text-3xl ${isAudioReactive ? '' : 'animate-pulse'}`} 
                            style={{ 
                              right: '25%', 
                              top: '25%',
                              transform: isAudioReactive ? `scale(${1 + audioLevels.mid}) rotate(${-audioLevels.mid * 360}deg)` : '',
                              transition: 'transform 0.1s ease-out'
                            }}
                          >
                            {ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)]}
                          </div>
                          <div 
                            className={`absolute text-3xl ${isAudioReactive ? '' : 'animate-bounce'}`} 
                            style={{ 
                              left: '50%', 
                              bottom: '25%',
                              transform: isAudioReactive ? `translateX(-50%) scale(${1 + audioLevels.bass})` : 'translateX(-50%)',
                              transition: 'transform 0.1s ease-out'
                            }}
                          >
                            {ALL_EMOJIS[Math.floor(Math.random() * ALL_EMOJIS.length)]}
                          </div>
                        </>
                      )}
                    </>
                  )}
                  
                  {/* Scanning Effect */}
                  {isActive && !personDetected && (
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent animate-pulse">
                      <div className="w-full h-1 bg-cyan-400 animate-ping absolute top-1/2 shadow-[0_0_20px_#22d3ee]"></div>
                      <div className="w-1 h-full bg-cyan-400 animate-ping absolute left-1/2 shadow-[0_0_20px_#22d3ee]"></div>
                    </div>
                  )}
                  
                  {/* Person Detection Indicator */}
                  {isActive && (
                    <div className="absolute top-4 left-4 bg-black/70 rounded-lg p-2 border border-cyan-500/50">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${personDetected ? 'bg-green-400 animate-pulse shadow-[0_0_10px_#4ade80]' : 'bg-red-400 animate-bounce shadow-[0_0_10px_#f87171]'}`}></div>
                        <span className="text-cyan-400 text-sm font-mono">
                          {personDetected ? '🎯 TARGET LOCKED' : '🔍 SCANNING...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {/* Mode Indicator */}
                  <div className="absolute top-4 right-4 bg-black/70 rounded-lg p-2 border border-purple-500/50">
                    <span className="text-purple-400 text-xs font-mono">
                      {currentSpecialMode} | {currentColorTheme.name}
                    </span>
                  </div>
                  
                  {/* Audio Reactive Visualizer */}
                  {isAudioReactive && isActive && (
                    <div className="absolute bottom-4 left-4 right-4 h-8 bg-black/50 rounded-lg overflow-hidden border border-cyan-500/30">
                      <div className="flex h-full">
                        {Array.from({ length: 20 }).map((_, i) => (
                          <div 
                            key={i} 
                            className="flex-1 bg-gradient-to-t from-cyan-500 to-purple-500"
                            style={{ 
                              height: `${(Math.sin(i * 0.5 + Date.now() * 0.003) * 0.5 + 0.5) * 100 * (audioLevels.bass + 0.2)}%`,
                              transition: 'height 0.1s ease-out'
                            }}
                          ></div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Placeholder when camera is off */}
                  {!isActive && (
                    <div className="w-full max-w-2xl h-96 bg-gradient-to-br from-gray-800 via-purple-900 to-black flex items-center justify-center border-2 border-purple-500/50">
                      <div className="text-center text-white">
                        <div className="text-6xl mb-4 animate-bounce">🎭</div>
                        <Camera className="w-16 h-16 mx-auto mb-4 opacity-50 animate-pulse text-cyan-400" />
                        <p className="text-xl text-cyan-400">Prepare for maximum mismatch!</p>
                        <p className="text-sm text-gray-400 mt-2">Your face will never be the same...</p>
                        <p className="text-xs text-purple-400 mt-2">🎵 Background music ready to rock!</p>
                        
                        {/* Audio Visualizer Preview */}
                        {musicEnabled && (
                          <div className="mt-4 max-w-xs mx-auto">
                            <AudioVisualizer audioSystem={audioSystemRef.current} />
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* Creative Frame Selector */}
              {isActive && (
                <Card className="p-4 bg-black/70 backdrop-blur-sm border-2 border-purple-500/30">
                  <div className="flex flex-wrap gap-2 justify-center">
                    <span className="text-sm font-medium text-cyan-400 mr-2 flex items-center gap-1">
                      <Gamepad2 className="w-4 h-4" />
                      🎨 Chaos Frames:
                    </span>
                    {CREATIVE_FRAMES.map((frame, index) => (
                      <Button
                        key={frame.name}
                        size="sm"
                        variant={selectedFrame === index ? "default" : "outline"}
                        onClick={async () => {
                          setSelectedFrame(index)
                          await playSound('click')
                        }}
                        className={`text-xs hover:scale-110 transition-transform ${
                          selectedFrame === index 
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                            : 'border-gray-600 text-gray-300 hover:border-purple-500 hover:text-purple-400'
                        }`}
                      >
                        {frame.name}
                      </Button>
                    ))}
                  </div>
                </Card>
              )}

              {/* Humorous Message */}
              {message && (
                <Card className={`p-6 bg-gradient-to-r from-black/80 to-purple-900/80 backdrop-blur-sm border-2 border-pink-500/50 ${beatDetected ? 'scale-105' : ''} transition-transform`}>
                  <p className="text-lg md:text-xl text-center font-medium text-cyan-400 mb-2">
                    {message}
                  </p>
                  {personDetected && emojiFixed && (
                    <p className="text-sm text-center text-pink-400 font-semibold animate-pulse">
                      ✨ Emoji locked until you escape our detection matrix! ✨
                    </p>
                  )}
                </Card>
              )}

              {/* Useless Fact */}
              {uselessFact && (
                <Card className={`p-4 bg-gradient-to-r from-yellow-900/80 to-orange-900/80 border-2 border-yellow-500/50 backdrop-blur-sm ${isAudioReactive ? 'transform-gpu' : ''}`} style={{
                  transform: isAudioReactive ? `translateY(${Math.sin(Date.now() * 0.002) * 5 * (audioLevels.mid + 0.5)}px)` : ''
                }}>
                  <p className="text-center text-yellow-400 font-medium">
                    💡 <strong>Completely Useless Fact:</strong> {uselessFact}
                  </p>
                </Card>
              )}

              {/* Controls */}
              <div className="flex flex-wrap gap-4 justify-center">
                {!isActive ? (
                  <Button 
                    onClick={startCamera}
                    size="lg"
                    className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 hover:from-purple-700 hover:via-pink-700 hover:to-red-700 text-white px-8 py-3 text-lg transform hover:scale-110 transition-all duration-300 shadow-[0_0_30px_rgba(168,85,247,0.5)] border border-purple-500"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    🚀 INITIATE CHAOS MODE
                  </Button>
                ) : (
                  <>
                    <Button 
                      onClick={stopCamera}
                      size="lg"
                      variant="destructive"
                      className="px-6 py-3 hover:scale-110 transition-transform bg-red-600 hover:bg-red-700 shadow-[0_0_20px_rgba(239,68,68,0.5)]"
                    >
                      <CameraOff className="w-5 h-5 mr-2" />
                      STOP MADNESS
                    </Button>
                    
                    <Button 
                      onClick={resetEmoji}
                      size="lg"
                      variant="outline"
                      className="px-6 py-3 hover:scale-110 transition-transform border-2 border-purple-500 text-purple-400 hover:bg-purple-500/20"
                      disabled={!emojiFixed}
                    >
                      <RotateCcw className="w-5 h-5 mr-2" />
                      🎲 NEW MISMATCH
                    </Button>
                    
                    <Button 
                      onClick={capturePhoto}
                      size="lg"
                      className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-6 py-3 hover:scale-110 transition-all duration-300 shadow-[0_0_20px_rgba(34,197,94,0.5)]"
                      disabled={!personDetected}
                    >
                      <Sparkles className="w-5 h-5 mr-2" />
                      📸 CAPTURE CHAOS
                    </Button>
                  </>
                )}
              </div>

              {/* Music Controls */}
              {audioInitialized && (
                <div className="flex flex-wrap gap-4 justify-center">
                  <Button 
                    onClick={toggleMusic}
                    variant="outline"
                    className={`border-2 border-green-500/50 hover:bg-green-500/20 hover:scale-105 transition-all text-green-400 ${musicEnabled ? 'bg-green-500/20' : ''}`}
                  >
                    <Music className="w-4 h-4 mr-2" />
                    {musicEnabled ? 'Stop Music' : 'Play Music'}
                  </Button>
                  
                  {musicEnabled && (
                    <Button 
                      onClick={() => {
                        const nextStyle = (musicStyle + 1) % MUSIC_STYLES.length
                        setMusicStyle(nextStyle)
                        playSound('theme')
                      }}
                      variant="outline"
                      className="border-2 border-cyan-500/50 hover:bg-cyan-500/20 hover:scale-105 transition-all text-cyan-400"
                    >
                      <Disc className="w-4 h-4 mr-2" />
                      Switch Style ({MUSIC_STYLES[musicStyle]})
                    </Button>
                  )}
                </div>
              )}

              {/* Completely Useless Button */}
              <Button 
                onClick={() => {
                  generateRandomFloatingEmojis()
                  triggerGlitch()
                }}
                variant="outline"
                className="border-2 border-dashed border-gray-600 hover:border-cyan-400 hover:scale-105 transition-all text-gray-400 hover:text-cyan-400 bg-black/50"
              >
                🎪 SHUFFLE ALL CHAOS (Completely Pointless)
              </Button>

              {/* Photo Gallery Toggle */}
              {capturedPhotos.length > 0 && (
                <Button 
                  onClick={async ()
